public record CourseInstructorsPut(List<int> InstructorIds);
