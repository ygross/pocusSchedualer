using Microsoft.AspNetCore.Routing;

namespace PocusSchedualer.Endpoints;

public static class HealthEndpoints
{
    public static void MapHealthEndpoints(this IEndpointRouteBuilder api)
    {
        api.MapGet("/health/db", async (Db db) =>
        {
            var ok = await db.IsDbAliveAsync();
            return Results.Ok(new { ok });
        });
    }
}
