using Microsoft.AspNetCore.Routing;

namespace PocusSchedualer.Endpoints;

/// <summary>
/// Availability endpoints for instructors (offer/cancel availability for ME).
/// Routes are relative to /api.
/// </summary>
public static class AvailabilityEndpoints
{
    public static void MapAvailabilityEndpoints(this IEndpointRouteBuilder api)
    {
        // POST: offer availability (for ME)
        api.MapPost("/activity-instances/{instanceId:int}/availability", async (
            HttpContext ctx,
            int instanceId,
            Db db) =>
        {
            var (isAuth, _, myId) = AuthHelpers.GetAuthInfo(ctx);
            if (!isAuth) return Results.Unauthorized();
            if (myId == null) return Results.Unauthorized();

            // allow Instructor/CourseManager/Admin
            if (!ctx.User.IsInRole(Roles.Instructor) &&
                !ctx.User.IsInRole(Roles.CourseManager) &&
                !ctx.User.IsInRole(Roles.Admin))
                return Results.Forbid();

            // hard lock if assigned
            if (await db.IsInstructorAssignedToInstanceAsync(instanceId, myId.Value))
                return Results.Conflict(new { ok = false, error = "Assigned instance is locked." });

            await db.UpsertInstructorAvailabilityAsync(instanceId, myId.Value);
            return Results.Ok(new { ok = true });
        });

        // DELETE: cancel availability (for ME)
        api.MapDelete("/activity-instances/{instanceId:int}/availability", async (
            HttpContext ctx,
            int instanceId,
            Db db) =>
        {
            var (isAuth, _, myId) = AuthHelpers.GetAuthInfo(ctx);
            if (!isAuth) return Results.Unauthorized();
            if (myId == null) return Results.Unauthorized();

            if (!ctx.User.IsInRole(Roles.Instructor) &&
                !ctx.User.IsInRole(Roles.CourseManager) &&
                !ctx.User.IsInRole(Roles.Admin))
                return Results.Forbid();

            if (await db.IsInstructorAssignedToInstanceAsync(instanceId, myId.Value))
                return Results.Conflict(new { ok = false, error = "Assigned instance is locked." });

            await db.DeleteInstructorAvailabilityAsync(instanceId, myId.Value);
            return Results.Ok(new { ok = true });
        });
    }
}
