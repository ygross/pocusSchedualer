using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace PocusSchedualer.Endpoints
{
    public static class AuthHelpers
    {
        /// <summary>
        /// Returns:
        ///  isAuth  - authenticated (cookie)
        ///  isAdmin - role=Admin
        ///  myId    - instructorId claim parsed to int (nullable)
        /// </summary>
        public static (bool isAuth, bool isAdmin, int? myId) GetAuthInfo(HttpContext ctx)
        {
            if (ctx?.User?.Identity?.IsAuthenticated != true)
                return (false, false, null);

            var isAdmin =
                ctx.User.IsInRole(Roles.Admin) ||
                string.Equals(ctx.User.FindFirstValue(ClaimTypes.Role), Roles.Admin, StringComparison.OrdinalIgnoreCase);

            // your codebase uses "instructorId"
            var s =
                ctx.User.FindFirst("instructorId")?.Value ??
                ctx.User.FindFirst("InstructorId")?.Value ??
                ctx.User.FindFirst("myInstructorId")?.Value;

            int? myId = int.TryParse(s, out var id) ? id : null;
            return (true, isAdmin, myId);
        }
    }
}
