using Microsoft.AspNetCore.Authentication.Cookies;
using PocusSchedualer.Endpoints;
using PocusSchedualer.Services;

var builder = WebApplication.CreateBuilder(args);

// ============================
// Services (DI)
// ============================
builder.Services.AddSingleton<Db>();

builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name = "SimPocusAuth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.None; // switch to Always when fully HTTPS
        options.Cookie.SameSite = SameSiteMode.Lax;
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", p => p.RequireRole(Roles.Admin));
    options.AddPolicy("CourseManagerOnly", p => p.RequireRole(Roles.CourseManager));
    options.AddPolicy("InstructorOnly", p => p.RequireRole(Roles.Instructor));
    options.AddPolicy("AnyUser", p => p.RequireRole(Roles.Admin, Roles.CourseManager, Roles.Instructor));
});

builder.Services.AddScoped<AuditService>();
builder.Services.AddScoped<EmailService>();

// ============================
// App
// ============================
var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();

// ============================
// API group: /api
// ============================
var api = app.MapGroup("/api");

// Endpoints (all routes inside are RELATIVE to /api)
api.MapHealthEndpoints();
api.MapAuthEndpoints();
api.MapActivitiesEndpoints();
api.MapLeadEndpoints();
api.MapAvailabilityEndpoints();
api.MapInstructorAvailabilityEndpoints();
api.MapInstructorCertEndpoints();
api.MapInstructorStatsEndpoints();

// Admin group: /api/admin
var admin = api.MapGroup("/admin");
admin.MapAdminEndpoints();

// ============================
// Static files
// ============================
app.UseDefaultFiles();
app.UseStaticFiles();

app.Run();
