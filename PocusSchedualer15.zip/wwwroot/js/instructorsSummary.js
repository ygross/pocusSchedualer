// instructorsSummary.js (תקין + auto base detect)
const $ = (id) => document.getElementById(id);

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

/* =========================
   Base-path detection
   ========================= */
function getAppPrefix() {
  // Example: /simcenter/PocusSchedualer/instructorsSummary.html  -> /simcenter/PocusSchedualer
  const m = location.pathname.match(/^(.*\/PocusSchedualer)\//i);
  return m ? m[1] : "";
}

async function tryBase(base) {
  // try /me as probe
  try {
    const res = await fetch(`${base}/me`, { credentials: "include" });
    return res.ok;
  } catch {
    return false;
  }
}

async function detectApiBase() {
  const prefix = getAppPrefix();

  // Candidates in order:
  // 1) /simcenter/PocusSchedualer/api  (when backend endpoints are directly under IIS app "api" without MapGroup("/api"))
  // 2) /simcenter/PocusSchedualer/api/api (when IIS app is "api" AND backend has MapGroup("/api"))
  // 3) /api (rare: api is at domain root)
  const candidates = [
    `${prefix}/api`,
    `${prefix}/api/api`,
    `/api`,
    `/api/api`
  ];

  for (const c of candidates) {
    if (await tryBase(c)) return c;
  }

  // fallback (keeps previous behavior but won't crash)
  return candidates[0];
}

/* =========================
   Utils
   ========================= */
async function safeFetchJson(url) {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status} - ${url}\n${txt}`.trim());
  }
  return res.json();
}

function showErr(msg) {
  const box = $("errBox");
  if (!box) return;
  box.style.display = "block";
  box.textContent = msg;
}

function clearErr() {
  const box = $("errBox");
  if (!box) return;
  box.style.display = "none";
  box.textContent = "";
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* =========================
   Pills
   ========================= */
function renderPills(containerId, items, emptyText) {
  const wrap = $(containerId);
  if (!wrap) return;

  wrap.innerHTML = "";

  if (!Array.isArray(items) || items.length === 0) {
    wrap.innerHTML = `<span class="cert-pill muted">${emptyText}</span>`;
    return;
  }

  items.forEach(t => {
    const pill = document.createElement("span");
    pill.className = "cert-pill";
    pill.textContent = t;
    wrap.appendChild(pill);
  });
}

/* =========================
   Loaders
   ========================= */
let apiBase = null;

async function loadMe() {
  const me = await safeFetchJson(`${apiBase}/me`);

  const fullName = me?.fullName ?? me?.FullName ?? "—";
  const roleName = me?.roleName ?? me?.RoleName ?? me?.role ?? me?.Role ?? "—";
  const email    = me?.email ?? me?.Email ?? "—";
  const dept     = me?.department ?? me?.Department ?? "";

  const loggedRole = $("loggedRole");
  if (loggedRole) {
    loggedRole.textContent = `תפקיד המשתמש המחובר שביצע לוגין דרך OTP: ${fullName} (${roleName})`;
  }

  const details = $("instructorDetails");
  if (details) {
    details.innerHTML = `
      <div><b>שם:</b> ${escapeHtml(fullName)}</div>
      <div><b>תפקיד:</b> ${escapeHtml(roleName)}</div>
      ${dept ? `<div><b>מחלקה:</b> ${escapeHtml(dept)}</div>` : ``}
      <div><b>אימייל:</b> ${escapeHtml(email)}</div>
    `;
  }

  return me;
}

async function loadCerts() {
  const certs = await safeFetchJson(`${apiBase}/instructors/certifications`);
  renderPills("certifications", certs, "אין הסמכות");
}

async function loadCourses() {
  // Requires backend endpoint:
  // GET {apiBase}/instructors/courses -> [{courseId, courseName}]
  const rows = await safeFetchJson(`${apiBase}/instructors/courses`);
  const names = (Array.isArray(rows) ? rows : [])
    .map(x => x.courseName ?? x.CourseName)
    .filter(Boolean);
  renderPills("courses", names, "אין קורסים");
}

/* ===== Stats (kept compatible) ===== */
function getTargets(period) {
  if (period === "week")    return { hours: 8,  instances: 4,  variety: 4 };
  if (period === "quarter") return { hours: 96, instances: 48, variety: 6 };
  return { hours: 32, instances: 16, variety: 4 };
}

function calcLoadIndex(period, totalHours, totalInstances, uniqueActivities) {
  const t = getTargets(period);
  const hoursScore = clamp(totalHours / t.hours, 0, 1);
  const instScore  = clamp(totalInstances / t.instances, 0, 1);
  const varScore   = clamp(uniqueActivities / t.variety, 0, 1);
  return Math.round(100 * (0.6 * hoursScore + 0.3 * instScore + 0.1 * varScore));
}

function loadStyle(loadIndex) {
  if (loadIndex >= 70) return { text: "עומס גבוה 🔴",  cssVar: "--bad" };
  if (loadIndex >= 40) return { text: "עומס בינוני 🟠", cssVar: "--warn" };
  return { text: "עומס נמוך 🟢", cssVar: "--good" };
}

function renderActivitiesTable(rows) {
  const tbody = $("activitiesTable");
  if (!tbody) return;

  tbody.innerHTML = "";

  if (!rows?.length) {
    tbody.innerHTML = `<tr><td colspan="3" class="muted">אין נתונים</td></tr>`;
    return;
  }

  rows.forEach(a => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(a.activityName ?? a.ActivityName)}</td>
      <td>${Number(a.instances ?? a.Instances ?? 0)}</td>
      <td>${Number(a.hours ?? a.Hours ?? 0).toFixed(1)}</td>
    `;
    tbody.appendChild(tr);
  });
}

async function loadStats() {
  const period = $("periodSelect")?.value ?? "month";
  const data = await safeFetchJson(`${apiBase}/instructors/stats?period=${encodeURIComponent(period)}`);

  const totalInstances = Number(data.totalInstances ?? data.TotalInstances ?? 0);
  const totalHours     = Number(data.totalHours ?? data.TotalHours ?? 0);
  const byActivity     = data.byActivity ?? data.ByActivity ?? [];

  if ($("totalInstances")) $("totalInstances").textContent = totalInstances;
  if ($("totalHours")) $("totalHours").textContent = totalHours.toFixed(1);

  renderActivitiesTable(byActivity);

  const loadIndex = calcLoadIndex(period, totalHours, totalInstances, byActivity.length);
  if ($("loadIndex")) $("loadIndex").textContent = loadIndex;

  const st = loadStyle(loadIndex);
  if ($("loadLabel")) $("loadLabel").textContent = st.text;

  const bar = $("loadBar");
  if (bar) {
    bar.style.width = `${loadIndex}%`;
    bar.style.background = `var(${st.cssVar})`;
  }
  const dot = $("loadDot");
  if (dot) dot.style.background = `var(${st.cssVar})`;
}

/* =========================
   Init
   ========================= */
async function refreshAll() {
  clearErr();
  try {
    if (!apiBase) apiBase = await detectApiBase();

    await loadMe();
    await loadCerts();
    await loadCourses();
    await loadStats();
  } catch (e) {
    console.error(e);
    showErr(e.message || String(e));
  }
}

document.addEventListener("DOMContentLoaded", () => {
  $("btnRefresh")?.addEventListener("click", refreshAll);
  $("periodSelect")?.addEventListener("change", loadStats);
  refreshAll();
});
