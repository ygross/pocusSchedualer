using Microsoft.Data.SqlClient;
using PocusSchedualer.Api.Dtos;

public partial class Db
{
    public async Task<InstructorStatsDto> GetInstructorStatsAsync(
        int instructorId,
        DateTime fromUtc,
        DateTime toUtc)
    {
        const string sql = @"
SELECT
    a.ActivityName,
    COUNT(DISTINCT i.InstanceId) AS Instances,
    CAST(SUM(DATEDIFF(MINUTE, i.StartUtc, i.EndUtc)) AS decimal(18,2)) / 60.0 AS Hours
FROM dbo.Assignments asg
JOIN dbo.ActivityInstances i ON i.InstanceId = asg.InstanceId
JOIN dbo.Activities a ON a.ActivityId = i.ActivityId
WHERE
    asg.InstructorId = @InstructorId
    AND asg.Status = N'Assigned'
    AND asg.CancelledAtUtc IS NULL
    AND i.IsCancelled = 0
    AND i.StartUtc >= @FromUtc AND i.StartUtc < @ToUtc
GROUP BY
    a.ActivityName
ORDER BY
    a.ActivityName;";

        var rows = new List<InstructorActivityRowDto>();

        await using var con = new SqlConnection(_cs);
        await con.OpenAsync();

        await using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@InstructorId", instructorId);
        cmd.Parameters.AddWithValue("@FromUtc", fromUtc);
        cmd.Parameters.AddWithValue("@ToUtc", toUtc);

        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            var name = r.GetString(0);
            var instances = r.GetInt32(1);
            var hours = r.IsDBNull(2) ? 0m : r.GetDecimal(2);
            rows.Add(new InstructorActivityRowDto(name, instances, hours));
        }

        var totalInstances = rows.Sum(x => x.Instances);
        var totalHours = rows.Sum(x => x.Hours);

        return new InstructorStatsDto(totalInstances, totalHours, rows);
    }
}
