using System.Security.Claims;
using PocusSchedualer.Api.Dtos;

namespace PocusSchedualer.Api.Endpoints;

public static class InstructorStatsEndpoints
{
    public static void MapInstructorStatsEndpoints(this WebApplication app)
    {
        app.MapGet("/api/api/instructors/stats", Handle);
        app.MapGet("/api/instructors/stats", Handle); // Alias (לא חובה, אבל מומלץ)
    }

    private static async Task<IResult> Handle(HttpContext ctx, string? period, Db db)
    {
        // לפי התמונה שלך /api/api/me מחזיר instructorId/email/fullName/roleName
        // אני מניח שה-auth שלך שם Email ב-Claims (כמו endpoints אחרים אצלך).
        var email = ctx.User.FindFirstValue(ClaimTypes.Email);
        if (string.IsNullOrWhiteSpace(email))
            return Results.Unauthorized();

        var me = await db.GetMeByEmailAsync(email); // צריך שיחזיר InstructorId
        if (me == null)
            return Results.Unauthorized();

        var (fromUtc, toUtc) = ResolveRange(period);

        var dto = await db.GetInstructorStatsAsync(me.InstructorId, fromUtc, toUtc);
        return Results.Ok(dto);
    }

    private static (DateTime FromUtc, DateTime ToUtc) ResolveRange(string? period)
    {
        var now = DateTime.UtcNow;
        var p = (period ?? "month").Trim().ToLowerInvariant();

        return p switch
        {
            "week"    => (now.Date.AddDays(-7),  now),
            "quarter" => (now.Date.AddDays(-90), now),
            _         => (now.Date.AddDays(-30), now),
        };
    }
}
