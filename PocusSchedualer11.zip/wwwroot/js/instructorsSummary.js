// instructor-summary.js
// =====================
window.__apiBase = window.__apiBase || "api/api";
const apiBase = window.__apiBase;
const $ = (id) => document.getElementById(id);

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function getTargets(period) {
  if (period === "week") return { hours: 8, instances: 4, variety: 4 };
  if (period === "quarter") return { hours: 96, instances: 48, variety: 4 };
  return { hours: 32, instances: 16, variety: 4 };
}

function calcLoadIndex(period, totalHours, totalInstances, uniqueActivities) {
  const t = getTargets(period);
  const hoursScore = clamp(totalHours / t.hours, 0, 1);
  const instScore = clamp(totalInstances / t.instances, 0, 1);
  const varScore = clamp(uniqueActivities / t.variety, 0, 1);
  return Math.round(100 * (0.6 * hoursScore + 0.3 * instScore + 0.1 * varScore));
}

function loadColorAndText(loadIndex) {
  if (loadIndex >= 70) return { text: "עומס גבוה 🔴", color: "var(--bad)" };
  if (loadIndex >= 40) return { text: "עומס בינוני 🟠", color: "var(--brown)" };
  return { text: "עומס נמוך 🟢", color: "var(--green)" };
}

async function safeFetchJson(url) {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status} - ${url}\n${txt}`);
  }
  return res.json();
}

function showErr(msg) {
  const box = $("errBox");
  if (!box) return;
  box.style.display = "block";
  box.textContent = msg;
}

function clearErr() {
  const box = $("errBox");
  if (!box) return;
  box.style.display = "none";
  box.textContent = "";
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderCertifications(certs) {
  const wrap = $("certifications");
  if (!wrap) return;
  wrap.innerHTML = "";

  const list = Array.isArray(certs) ? certs : [];
  if (!list.length) {
    wrap.innerHTML = `<span class="muted">אין הסמכות להצגה</span>`;
    return;
  }

  list.forEach((c) => {
    const s = document.createElement("span");
    s.className = "cert-pill";
    s.textContent = c;
    wrap.appendChild(s);
  });
}

function renderActivitiesTable(rows) {
  const tbody = $("activitiesTable");
  if (!tbody) return;

  const by = Array.isArray(rows) ? rows : [];
  tbody.innerHTML = "";

  if (!by.length) {
    tbody.innerHTML = `<tr><td colspan="3" class="muted">אין נתונים לתקופה שנבחרה</td></tr>`;
    return;
  }

  by.forEach((a) => {
    const name = a?.activityName ?? "—";
    const instances = Number(a?.instances || 0);
    const hours = Number(a?.hours || 0);

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(name)}</td>
      <td>${instances}</td>
      <td>${hours.toFixed(1)}</td>
    `;
    tbody.appendChild(tr);
  });
}

async function loadMe() {
  // אם יש requireUser גלובלי מהתפריט – נשתמש בו. אחרת ניפול ל-API ישיר.
  const me = (typeof window.requireUser === "function")
    ? await window.requireUser()
    : await safeFetchJson(`${apiBase}/me`);

  const fullName = me?.fullName || "—";
  const rolesArr = Array.isArray(me?.roles) ? me.roles : [];
  const rolesTxt = rolesArr.length ? rolesArr.join(", ") : "—";

  const loggedRole = $("loggedRole");
  if (loggedRole) loggedRole.textContent = `משתמש מחובר: ${fullName} (${rolesTxt})`;

  const details = $("instructorDetails");
  if (details) {
    details.innerHTML = `
      <div><b>שם:</b> ${escapeHtml(fullName)}</div>
      <div><b>תפקידים:</b> ${escapeHtml(rolesTxt)}</div>
    `;
  }

  renderCertifications(me?.certifications);
}

async function loadStats() {
  const period = $("periodSelect")?.value || "month";
  const data = await safeFetchJson(`${apiBase}/instructors/stats?period=${encodeURIComponent(period)}`);

  const totalInstances = Number(data?.totalInstances || 0);
  const totalHours = Number(data?.totalHours || 0);
  const byActivity = Array.isArray(data?.byActivity) ? data.byActivity : [];

  $("totalInstances").textContent = String(totalInstances);
  $("totalHours").textContent = totalHours.toFixed(1);

  renderActivitiesTable(byActivity);

  const uniqueActivities = byActivity.length;
  const loadIndex = calcLoadIndex(period, totalHours, totalInstances, uniqueActivities);

  $("loadIndex").textContent = String(loadIndex);

  const { text, color } = loadColorAndText(loadIndex);
  $("loadLabel").textContent = text;
  $("loadInfo").textContent = `${uniqueActivities} פעילויות שונות`;

  const bar = $("loadBar");
  if (bar) {
    bar.style.width = `${loadIndex}%`;
    bar.style.background = color;
  }
}

async function refreshAll() {
  clearErr();
  try {
    await loadMe();
    await loadStats();
  } catch (e) {
    console.error(e);
    showErr("שגיאה בטעינת הנתונים:\n" + (e?.message || e));
  }
}

document.addEventListener("DOMContentLoaded", () => {
  $("btnRefresh")?.addEventListener("click", refreshAll);
  $("periodSelect")?.addEventListener("change", () => loadStats().catch(e => showErr(e?.message || e)));
  refreshAll();
});
