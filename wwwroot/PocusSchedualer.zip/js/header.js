// בדיקת בריאות DB
const HEALTH_URL = "/simcenter/PocusSchedualer/api/api/health/db";

async function checkDbHealth() {
    const dot  = document.getElementById("db-dot");
    const text = document.getElementById("db-status-text");
    if (!dot || !text) return;

    try {
        const resp = await fetch(HEALTH_URL, { cache: "no-cache" });

        if (!resp.ok) {
            dot.classList.remove("ok");
            dot.classList.add("err");
            text.textContent = "שגיאה";
            return;
        }

        const data = await resp.json().catch(() => ({}));
        dot.classList.remove("err");
        dot.classList.add("ok");
        text.textContent = "מחובר";
        // אפשר להציג גם זמן DB אם תרצה:
        // console.log("DB time:", data.dbTime);
    } catch (e) {
        console.error("DB HEALTH ERROR", e);
        dot.classList.remove("ok");
        dot.classList.add("err");
        text.textContent = "לא מחובר";
    }
}

document.addEventListener("DOMContentLoaded", () => {
    checkDbHealth();
    // רענון כל חצי דקה
    setInterval(checkDbHealth, 30000);
});
