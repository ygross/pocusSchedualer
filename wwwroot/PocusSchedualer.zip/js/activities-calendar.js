// API base – כמו ב-addActivities.js כדי לעבוד אותו דבר
const API_BASE = "/simcenter/PocusSchedualer/api/api";

let calendarData = [];   // נתוני מופעים מהשרת
let currentMonth;        // תאריך שמייצג את החודש המוצג בקלנדר
let selectedDay;         // נשאר לשימוש עתידי (כבר לא קריטי בגאנט החודשי)

document.addEventListener("DOMContentLoaded", initCalendarPage);

async function initCalendarPage() {
    const today = new Date();
    currentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    selectedDay = today;

    // מילוי שדות תאריך
    const dateFromInput = document.getElementById("dateFrom");
    const dateToInput   = document.getElementById("dateTo");

    const from = new Date(today.getFullYear(), today.getMonth(), 1);
    const to   = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    dateFromInput.value = toIsoDate(from);
    dateToInput.value   = toIsoDate(to);

    // טעינת סוגי פעילות לפילטר
    await loadActivityTypeFilter();

    // כפתורים
    document.getElementById("btnToday").addEventListener("click", () => {
        const now = new Date();
        currentMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        selectedDay = now;
        dateFromInput.value = toIsoDate(now);
        dateToInput.value   = toIsoDate(now);
        refreshData();
    });

    document.getElementById("btnPrevMonth").addEventListener("click", () => {
        currentMonth.setMonth(currentMonth.getMonth() - 1);
        syncMonthToInputs();
        refreshData();
    });

    document.getElementById("btnNextMonth").addEventListener("click", () => {
        currentMonth.setMonth(currentMonth.getMonth() + 1);
        syncMonthToInputs();
        refreshData();
    });

    document.getElementById("btnRefresh").addEventListener("click", () => {
        refreshData();
    });

    // שינוי פילטר סוג פעילות
    document.getElementById("activityTypeFilter").addEventListener("change", () => {
        refreshData();
    });

    // שינוי תאריכי FROM/TO
    dateFromInput.addEventListener("change", () => {
        const d = parseIsoDate(dateFromInput.value);
        if (d) {
            selectedDay = d;
            currentMonth = new Date(d.getFullYear(), d.getMonth(), 1);
        }
        refreshData();
    });
    dateToInput.addEventListener("change", refreshData);

    // מילוי כותרות ימים בקלאנדר
    buildCalendarWeekHeader();
    // בגאנט – כותרת חודשית (נבנה מחדש בתוך renderGantt)
    buildGanttHoursHeader();

    // רענון ראשון
    refreshData();
}

/* ==================== API – סוגי פעילות / נתוני קלנדר ==================== */

async function loadActivityTypeFilter() {
    const sel = document.getElementById("activityTypeFilter");
    sel.innerHTML = "<option value=''>טוען...</option>";

    try {
        const resp = await fetch(`${API_BASE}/activity-types`, { cache: "no-cache" });
        if (!resp.ok) throw new Error("HTTP " + resp.status);
        const list = await resp.json();

        sel.innerHTML = "<option value=''>כל הסוגים</option>";

        if (Array.isArray(list)) {
            for (const t of list) {
                const id   = t.ActivityTypeId ?? t.activityTypeId;
                const name = t.TypeName       ?? t.typeName;
                if (!id || !name) continue;
                const opt = document.createElement("option");
                opt.value = id;
                opt.textContent = name;
                sel.appendChild(opt);
            }
        }
    } catch (err) {
        console.error("ACTIVITY TYPE FILTER ERROR", err);
        sel.innerHTML = "<option value=''>שגיאה בטעינה</option>";
    }
}

async function refreshData() {
    const fromStr = document.getElementById("dateFrom").value;
    const toStr   = document.getElementById("dateTo").value;
    const typeId  = document.getElementById("activityTypeFilter").value || null;

    const calendarMsg = document.getElementById("calendarMessage");
    const ganttMsg    = document.getElementById("ganttMessage");
    const badge       = document.getElementById("summaryBadge");

    calendarMsg.textContent = "";
    ganttMsg.textContent    = "";
    badge.textContent       = "טוען נתונים...";

    const from = parseIsoDate(fromStr);
    const to   = parseIsoDate(toStr);

    if (!from || !to) {
        calendarMsg.textContent = "נא לבחור טווח תאריכים תקין";
        ganttMsg.textContent    = "נא לבחור טווח תאריכים תקין";
        badge.textContent       = "טווח תאריכים לא תקין";
        return;
    }

    try {
        const params = new URLSearchParams();
        params.set("from", fromStr);
        params.set("to",   toStr);
        if (typeId) params.set("activityTypeId", typeId);

        const url = `${API_BASE}/activities/calendar?${params.toString()}`;
        const resp = await fetch(url, { cache: "no-cache" });
        if (!resp.ok) {
            const txt = await resp.text();
            console.error("CALENDAR API ERROR", resp.status, txt);
            calendarMsg.textContent = "שגיאה בקריאת הנתונים מהשרת";
            ganttMsg.textContent    = "שגיאה בקריאת הנתונים מהשרת";
            badge.textContent       = "שגיאה בשרת";
            return;
        }

        const list = await resp.json();
        calendarData = Array.isArray(list) ? list : [];

        updateSummaryBadge(from, to, typeId);
        renderCalendar();
        renderGantt();
    } catch (err) {
        console.error("CALENDAR FETCH ERROR", err);
        calendarMsg.textContent = "שגיאה בטעינת הנתונים";
        ganttMsg.textContent    = "שגיאה בטעינת הנתונים";
        badge.textContent       = "שגיאה בטעינה";
    }
}

/* ==================== SUMMARY BADGE ==================== */

function updateSummaryBadge(from, to, typeId) {
    const badge = document.getElementById("summaryBadge");

    const activitiesSet = new Set();
    let instancesCount = 0;

    for (const row of calendarData) {
        if (row.ActivityId != null) {
            activitiesSet.add(row.ActivityId);
        }
        instancesCount++;
    }

    const actCount = activitiesSet.size;

    const rangeText = `${formatDateShort(from)}–${formatDateShort(to)}`;
    const filterText = typeId ? " · מסונן לפי סוג פעילות" : "";

    badge.textContent = `${actCount} פעילויות · ${instancesCount} מופעים · ${rangeText}${filterText}`;
}

/* ==================== CALENDAR RENDERING ==================== */

function buildCalendarWeekHeader() {
    const container = document.getElementById("calendarHeaderRow");
    container.innerHTML = "";
    const days = ["א׳","ב׳","ג׳","ד׳","ה׳","ו׳","ש׳"];

    for (const d of days) {
        const div = document.createElement("div");
        div.className = "calendar-header";
        div.textContent = d;
        container.appendChild(div);
    }
}

function renderCalendar() {
    const title = document.getElementById("calendarTitle");
    const daysContainer = document.getElementById("calendarDays");
    const msg = document.getElementById("calendarMessage");

    daysContainer.innerHTML = "";
    msg.textContent = "";

    const month = currentMonth.getMonth();
    const year  = currentMonth.getFullYear();

    title.textContent = `${monthNameHeb(month)} ${year}`;

    // קיבוץ מופעים לפי תאריך (מקומי)
    const byDate = new Map();
    for (const row of calendarData) {
        const dStart = new Date(row.startUtc ?? row.StartUtc);
        const key = toIsoDate(dStart);
        if (!byDate.has(key)) byDate.set(key, []);
        byDate.get(key).push(row);
    }

    // חישוב היום הראשון ברשת (ראשון בשבוע)
    const firstOfMonth = new Date(year, month, 1);
    const firstDow = firstOfMonth.getDay(); // 0=ראשון
    const startGrid = new Date(year, month, 1 - firstDow);

    // 6 שבועות * 7 ימים = 42 תאים
    for (let i = 0; i < 42; i++) {
        const d = new Date(startGrid);
        d.setDate(startGrid.getDate() + i);

        const dateStr = toIsoDate(d);
        const isCurrentMonth = d.getMonth() === month;

        const cell = document.createElement("div");
        cell.className = "calendar-day" + (isCurrentMonth ? "" : " outside");

        const header = document.createElement("div");
        header.className = "calendar-day-header";

        const numSpan = document.createElement("span");
        numSpan.className = "calendar-day-number";
        numSpan.textContent = d.getDate();

        const countSpan = document.createElement("span");
        countSpan.className = "calendar-day-count";

        const list = byDate.get(dateStr) || [];
        if (list.length > 0) {
            countSpan.textContent = `${list.length} מופעים`;
        } else {
            countSpan.textContent = "";
        }

        header.appendChild(numSpan);
        header.appendChild(countSpan);
        cell.appendChild(header);

        const eventsDiv = document.createElement("div");
        eventsDiv.className = "calendar-events";

        const maxVisible = 3;
        const toShow = list.slice(0, maxVisible);

        for (const item of toShow) {
            const ev = document.createElement("div");
            ev.className = "calendar-event";

            const name = item.ActivityName ?? item.activityName ?? "";
            const typeName = item.TypeName ?? item.typeName ?? "";

            const start = new Date(item.startUtc ?? item.StartUtc);
            const end   = new Date(item.endUtc   ?? item.EndUtc);

            const centerName =
                item.CenterName     ?? item.centerName ??
                item.RoomName       ?? item.roomName   ??
                item.DepartmentName ?? item.departmentName ?? "";

            const timeStr = `${timeShort(start)}–${timeShort(end)}`;
            const label = name || typeName || "מופע";

            // בכל אייטם בקלנדר – שעות + מרכז + שם הפעילות
            if (centerName) {
                ev.textContent = `${timeStr} · ${centerName} · ${label}`;
            } else {
                ev.textContent = `${timeStr} · ${label}`;
            }

            eventsDiv.appendChild(ev);
        }

        if (list.length > maxVisible) {
            const more = document.createElement("div");
            more.className = "calendar-more";
            more.textContent = `+${list.length - maxVisible} נוספים`;
            eventsDiv.appendChild(more);
        }

        // לחיצה על היום – אפשר לשמור לוגיקה עתידית (כבר לא חובה לגאנט חודשי)
        cell.addEventListener("click", () => {
            selectedDay = d;
            renderGantt();
        });

        cell.appendChild(eventsDiv);
        daysContainer.appendChild(cell);
    }

    if (calendarData.length === 0) {
        msg.textContent = "לא נמצאו מופעים בטווח התאריכים הנבחר.";
    }
}

/* ==================== GANTT – חודשי ==================== */

// שימוש באותה פונקציה, אבל לבניית כותרת חודשי (ימים בחודש)
function buildGanttHoursHeader() {
    const container = document.getElementById("ganttHeaderRow");
    container.innerHTML = "";

    const label = document.createElement("div");
    label.className = "gantt-header-cell";
    label.textContent = "פעילות / מרכז";
    container.appendChild(label);

    const month = currentMonth.getMonth();
    const year  = currentMonth.getFullYear();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    for (let day = 1; day <= daysInMonth; day++) {
        const cell = document.createElement("div");
        cell.className = "gantt-header-cell gantt-header-day";
        cell.textContent = day;
        container.appendChild(cell);
    }
}

function renderGantt() {
    const rowsContainer = document.getElementById("ganttRows");
    const msg = document.getElementById("ganttMessage");
    const title = document.getElementById("ganttTitle");

    rowsContainer.innerHTML = "";
    msg.textContent = "";

    const month = currentMonth.getMonth();
    const year  = currentMonth.getFullYear();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // כותרת
    title.textContent = `גאנט חודשי – ${monthNameHeb(month)} ${year}`;

    // כותרת ימים
    buildGanttHoursHeader();

    if (!calendarData || calendarData.length === 0) {
        msg.textContent = "אין מופעים בחודש הנבחר.";
        return;
    }

    const minDay = 1;
    const maxDay = daysInMonth;
    const totalSpan = maxDay - minDay + 1;

    // כל שורה = מופע (instance)
    for (const item of calendarData) {
        const start = new Date(item.startUtc ?? item.StartUtc);
        const end   = new Date(item.endUtc   ?? item.EndUtc);

        // רק מופעים שנמצאים באותו החודש המוצג
        if (start.getFullYear() !== year || start.getMonth() !== month) {
            continue;
        }

        const dayStart = start.getDate();
        const dayEnd   = end.getDate();

        let clampedStart = Math.max(dayStart, minDay);
        let clampedEnd   = Math.min(dayEnd,   maxDay);
        if (clampedEnd < clampedStart) clampedEnd = clampedStart;

        const leftPct  = ((clampedStart - minDay) / totalSpan) * 100;
        const widthPct = ((clampedEnd - clampedStart + 1) / totalSpan) * 100;

        const rowDiv = document.createElement("div");
        rowDiv.className = "gantt-row";

        const labelDiv = document.createElement("div");
        labelDiv.className = "gantt-row-label";

        const activityName = item.ActivityName ?? item.activityName ?? "פעילות";
        const centerName =
            item.CenterName     ?? item.centerName ??
            item.RoomName       ?? item.roomName   ??
            item.DepartmentName ?? item.departmentName ?? "";

        const startStr = timeShort(start);
        const endStr   = timeShort(end);

        // כותרת שורה: שם פעילות
        labelDiv.textContent = activityName;

        // שורה קטנה מתחת עם מרכז + שעות
        const details = document.createElement("div");
        details.className = "gantt-row-details";
        const parts = [];
        if (centerName) parts.push(centerName);
        parts.push(`${startStr}–${endStr}`);
        details.textContent = parts.join(" · ");
        labelDiv.appendChild(details);

        rowDiv.appendChild(labelDiv);

        const cellsDiv = document.createElement("div");
        cellsDiv.className = "gantt-row-cells";

        const bar = document.createElement("div");
        bar.className = "gantt-bar";
        bar.style.left  = `${leftPct}%`;
        bar.style.width = `${widthPct}%`;

        bar.title = `${activityName} | ${centerName || ""} | ${startStr}–${endStr}`;
        bar.textContent = `${startStr}–${endStr}${centerName ? " · " + centerName : ""}`;

        cellsDiv.appendChild(bar);
        rowDiv.appendChild(cellsDiv);
        rowsContainer.appendChild(rowDiv);
    }

    if (!rowsContainer.hasChildNodes()) {
        msg.textContent = "אין מופעים בחודש הנבחר.";
    }
}

/* ==================== HELPERS ==================== */

function toIsoDate(d) {
    if (!(d instanceof Date)) return "";
    const y = d.getFullYear();
    const m = pad2(d.getMonth() + 1);
    const day = pad2(d.getDate());
    return `${y}-${m}-${day}`;
}

function parseIsoDate(s) {
    if (!s) return null;
    const parts = s.split("-");
    if (parts.length !== 3) return null;
    const y = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10) - 1;
    const d = parseInt(parts[2], 10);
    const dt = new Date(y, m, d);
    if (isNaN(dt.getTime())) return null;
    return dt;
}

function pad2(n) {
    return n < 10 ? "0" + n : "" + n;
}

function monthNameHeb(m) {
    const names = [
        "ינואר","פברואר","מרץ","אפריל","מאי","יוני",
        "יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר"
    ];
    return names[m] || "";
}

function formatDateShort(d) {
    if (!(d instanceof Date)) return "";
    return `${pad2(d.getDate())}.${pad2(d.getMonth() + 1)}.${d.getFullYear()}`;
}

function timeShort(d) {
    if (!(d instanceof Date)) return "";
    return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

function syncMonthToInputs() {
    const dateFromInput = document.getElementById("dateFrom");
    const dateToInput   = document.getElementById("dateTo");

    const from = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
    const to   = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0);

    dateFromInput.value = toIsoDate(from);
    dateToInput.value   = toIsoDate(to);
}
