// js/login-otp.js (מעודכן)

const API_BASE = "api"; // ✅ היה /simcenter/PocusSchedualer/api/api

document.addEventListener("DOMContentLoaded", () => {
  const emailInput = document.getElementById("email");
  const otpInput = document.getElementById("otp");
  const btnSend = document.getElementById("btnSend");
  const btnVerify = document.getElementById("btnVerify");
  const otpSection = document.getElementById("otpSection");
  const msg = document.getElementById("msg");

  const missing = [];
  if (!emailInput) missing.push("#email");
  if (!btnSend) missing.push("#btnSend");
  if (!otpSection) missing.push("#otpSection");
  if (!otpInput) missing.push("#otp");
  if (!btnVerify) missing.push("#btnVerify");
  if (!msg) missing.push("#msg");

  if (missing.length) {
    console.error("login-otp.js missing elements:", missing.join(", "));
    return;
  }

  function showMessage(text, isError = false) {
    msg.textContent = text;
    msg.className = "msg " + (isError ? "error" : "success");
  }

  btnSend.addEventListener("click", sendOtp);
  btnVerify.addEventListener("click", verifyOtp);

  async function sendOtp() {
    const email = emailInput.value.trim();
    if (!email) return showMessage("יש להזין אימייל", true);

    btnSend.disabled = true;
    showMessage("שולח קוד...");

    try {
      const r = await fetch(`${API_BASE}/auth/otp/request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include", // ✅ הוסף כדי לשמור עקביות
        body: JSON.stringify({ email })
      });

      if (r.status === 404) {
        // לא קיים מדריך -> מעבר למסך יצירה
        window.location.href = `create-instructor.html?email=${encodeURIComponent(email)}`;
        return;
      }
      if (!r.ok) throw new Error();

      otpSection.style.display = "block";
      showMessage("קוד נשלח למייל");
      otpInput.focus();
    } catch {
      showMessage("שגיאה בשליחת הקוד", true);
    } finally {
      btnSend.disabled = false;
    }
  }

  async function verifyOtp() {
    const email = emailInput.value.trim();
    const code = otpInput.value.trim();
    if (!code) return showMessage("יש להזין קוד", true);

    btnVerify.disabled = true;
    showMessage("מאמת קוד...");

    try {
      const r = await fetch(`${API_BASE}/auth/otp/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include", // ✅ חובה כדי שה-Set-Cookie יישמר
        body: JSON.stringify({ email, code })
      });

      if (!r.ok) throw new Error();

      showMessage("התחברת בהצלחה");

      // ✅ מעבר ל-app.html לאחר הצלחה
      setTimeout(() => (window.location.href = "app.html"), 600);
    } catch {
      showMessage("קוד שגוי או שפג תוקפו", true);
    } finally {
      btnVerify.disabled = false;
    }
  }
});
