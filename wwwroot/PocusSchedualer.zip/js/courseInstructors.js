// ===== הגדרות API =====
// צפוי שיהיו בצד השרת (Program.cs):
// GET  /api/courses                  → רשימת קורסים
// GET  /api/instructors              → רשימת מדריכים
// GET  /api/course-instructors/{id}  → [1,2,3]
// PUT  /api/course-instructors/{id}  → { instructorIds: [...] }

const COURSES_API = "/api/courses";
const INSTRUCTORS_API = "/api/instructors";
const COURSE_INSTRUCTORS_API = "/api/course-instructors";

const courseSelect = document.getElementById("courseSelect");
const courseMessage = document.getElementById("courseMessage");

const instructorsContainer = document.getElementById("instructorsContainer");
const instructorFilterInput = document.getElementById("instructorFilter");
const btnSelectAll = document.getElementById("btnSelectAll");
const btnClearAll = document.getElementById("btnClearAll");
const btnSaveAssignments = document.getElementById("btnSaveAssignments");
const assignMessage = document.getElementById("assignMessage");

const badgeSelected = document.getElementById("badgeSelected");
const badgeTotal = document.getElementById("badgeTotal");

let allCourses = [];
let allInstructors = [];
let selectedCourseId = null;
let assignedInstructorIds = new Set(); // מזהי מדריכים משויכים לקורס הנבחר

// ===== init ראשוני =====
async function init() {
    courseMessage.textContent = "טוען קורסים ומדריכים...";
    assignMessage.textContent = "";
    assignMessage.className = "message";

    try {
        await Promise.all([loadCourses(), loadInstructors()]);
        courseMessage.textContent = "בחר קורס כדי לראות/לעדכן את השיוך.";
        courseMessage.className = "message";
    } catch (err) {
        console.error(err);
        courseMessage.textContent = "שגיאה בטעינת נתונים: " + err.message;
        courseMessage.className = "message error";
    }
}

// ===== קורסים =====
async function loadCourses() {
    const res = await fetch(COURSES_API, {
        method: "GET",
        headers: { "Accept": "application/json" }
    });

    if (!res.ok) {
        throw new Error("שגיאה בטעינת קורסים. קוד: " + res.status);
    }

    const data = await res.json();
    allCourses = Array.isArray(data) ? data : [];

    courseSelect.innerHTML = '<option value="">— בחר קורס —</option>';

    allCourses
        .sort((a, b) => {
            const providerA = (a.provider ?? a.Provider ?? "").toLowerCase();
            const providerB = (b.provider ?? b.Provider ?? "").toLowerCase();
            const nameA = (a.courseName ?? a.CourseName ?? "").toLowerCase();
            const nameB = (b.courseName ?? b.CourseName ?? "").toLowerCase();
            return (providerA + " " + nameA).localeCompare(providerB + " " + nameB);
        })
        .forEach(c => {
            const id = c.id ?? c.courseId ?? c.CourseId;
            const provider = c.provider ?? c.Provider ?? "";
            const name = c.courseName ?? c.CourseName ?? "";
            const isActive = c.isActive ?? c.IsActive;

            const option = document.createElement("option");
            option.value = id;
            option.textContent = (provider ? provider + " - " : "") + name;
            if (isActive === false) {
                option.textContent += " (לא פעיל)";
            }
            courseSelect.appendChild(option);
        });
}

// ===== מדריכים =====
async function loadInstructors() {
    const res = await fetch(INSTRUCTORS_API, {
        method: "GET",
        headers: { "Accept": "application/json" }
    });

    if (!res.ok) {
        throw new Error("שגיאה בטעינת מדריכים. קוד: " + res.status);
    }

    const data = await res.json();
    allInstructors = Array.isArray(data) ? data : [];

    badgeTotal.textContent = "סה״כ מדריכים במערכת: " + allInstructors.length;
    renderInstructorsList();
}

// ===== רינדור רשימת מדריכים =====
function renderInstructorsList() {
    const filterText = (instructorFilterInput.value || "").toLowerCase();
    instructorsContainer.innerHTML = "";

    const filtered = allInstructors.filter(inst => {
        const fullName = (inst.fullName ?? inst.FullName ??
            ((inst.firstName ?? inst.FirstName ?? "") + " " + (inst.lastName ?? inst.LastName ?? "")))
            .toLowerCase();
        const email = (inst.email ?? inst.Email ?? "").toLowerCase();

        return fullName.includes(filterText) || email.includes(filterText);
    });

    filtered.forEach(inst => {
        const id = inst.id ?? inst.instructorId ?? inst.InstructorId;
        const fullName = inst.fullName ?? inst.FullName ??
            ((inst.firstName ?? inst.FirstName ?? "") + " " + (inst.lastName ?? inst.LastName ?? ""));
        const email = inst.email ?? inst.Email ?? "";
        const isActive = inst.isActive ?? inst.IsActive;

        const row = document.createElement("div");
        row.className = "instructor-row";

        const main = document.createElement("div");
        main.className = "instructor-main";

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.checked = assignedInstructorIds.has(id);
        checkbox.addEventListener("change", () => {
            if (checkbox.checked) {
                assignedInstructorIds.add(id);
            } else {
                assignedInstructorIds.delete(id);
            }
            updateSelectedBadge();
        });

        const details = document.createElement("div");
        details.className = "instructor-details";

        const nameEl = document.createElement("span");
        nameEl.className = "instructor-name";
        nameEl.textContent = fullName || "(ללא שם)";

        const emailEl = document.createElement("span");
        emailEl.className = "instructor-email";
        emailEl.textContent = email;

        details.appendChild(nameEl);
        details.appendChild(emailEl);

        main.appendChild(checkbox);
        main.appendChild(details);

        const meta = document.createElement("div");
        meta.className = "instructor-meta";

        const roleBadge = document.createElement("span");
        roleBadge.className = "badge";
        roleBadge.textContent = "מדריך";
        meta.appendChild(roleBadge);

        if (isActive === false) {
            const inactiveBadge = document.createElement("span");
            inactiveBadge.className = "badge inactive";
            inactiveBadge.textContent = "לא פעיל";
            meta.appendChild(inactiveBadge);
        }

        row.appendChild(main);
        row.appendChild(meta);

        instructorsContainer.appendChild(row);
    });

    updateSelectedBadge();
}

// ===== עדכון מונה משויכים =====
function updateSelectedBadge() {
    badgeSelected.textContent =
        "מס’ מדריכים משויכים: " + assignedInstructorIds.size;
}

// ===== טעינת שיוכים לקורס =====
async function loadCourseAssignments(courseId) {
    if (!courseId) {
        selectedCourseId = null;
        assignedInstructorIds = new Set();
        btnSaveAssignments.disabled = true;
        renderInstructorsList();
        assignMessage.textContent = "יש לבחור קורס כדי להציג שיוכים.";
        assignMessage.className = "message";
        return;
    }

    assignMessage.textContent = "טוען שיוכי מדריכים לקורס...";
    assignMessage.className = "message";

    try {
        const url = `${COURSE_INSTRUCTORS_API}/${encodeURIComponent(courseId)}`;
        const res = await fetch(url, {
            method: "GET",
            headers: { "Accept": "application/json" }
        });

        if (!res.ok) {
            const text = await res.text();
            throw new Error("שגיאה בטעינת שיוכים. קוד: " + res.status + " פרטים: " + text);
        }

        // מצפה ל־Array של IDs
        const data = await res.json();
        const ids = Array.isArray(data) ? data : [];
        assignedInstructorIds = new Set(ids);

        selectedCourseId = courseId;
        btnSaveAssignments.disabled = false;

        renderInstructorsList();

        assignMessage.textContent = "ניטען. ניתן לעדכן ולשמור.";
        assignMessage.className = "message ok";
    } catch (err) {
        console.error(err);
        assignMessage.textContent = "שגיאה בטעינת שיוכים: " + err.message;
        assignMessage.className = "message error";
        btnSaveAssignments.disabled = true;
    }
}

// ===== שמירת שיוכים =====
async function saveAssignments() {
    if (!selectedCourseId) {
        assignMessage.textContent = "לא נבחר קורס.";
        assignMessage.className = "message error";
        return;
    }

    btnSaveAssignments.disabled = true;
    assignMessage.textContent = "שומר שיוכים...";
    assignMessage.className = "message";

    const body = {
        instructorIds: Array.from(assignedInstructorIds)
    };

    try {
        const url = `${COURSE_INSTRUCTORS_API}/${encodeURIComponent(selectedCourseId)}`;
        const res = await fetch(url, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(body)
        });

        if (!res.ok) {
            const text = await res.text();
            throw new Error("שגיאה בשמירת שיוכים. קוד: " + res.status + " פרטים: " + text);
        }

        assignMessage.textContent = "השיוך נשמר בהצלחה.";
        assignMessage.className = "message ok";
    } catch (err) {
        console.error(err);
        assignMessage.textContent = "שגיאה בשמירה: " + err.message;
        assignMessage.className = "message error";
    } finally {
        btnSaveAssignments.disabled = false;
    }
}

// ===== סימון / ניקוי לפי פילטר =====
function selectAllFiltered() {
    const filterText = (instructorFilterInput.value || "").toLowerCase();

    allInstructors.forEach(inst => {
        const fullName = (inst.fullName ?? inst.FullName ??
            ((inst.firstName ?? inst.FirstName ?? "") + " " + (inst.lastName ?? inst.LastName ?? "")))
            .toLowerCase();
        const email = (inst.email ?? inst.Email ?? "").toLowerCase();
        const match = fullName.includes(filterText) || email.includes(filterText);
        const id = inst.id ?? inst.instructorId ?? inst.InstructorId;

        if (match) {
            assignedInstructorIds.add(id);
        }
    });

    renderInstructorsList();
}

function clearAllFiltered() {
    const filterText = (instructorFilterInput.value || "").toLowerCase();

    allInstructors.forEach(inst => {
        const fullName = (inst.fullName ?? inst.FullName ??
            ((inst.firstName ?? inst.FirstName ?? "") + " " + (inst.lastName ?? inst.LastName ?? "")))
            .toLowerCase();
        const email = (inst.email ?? inst.Email ?? "").toLowerCase();
        const match = fullName.includes(filterText) || email.includes(filterText);
        const id = inst.id ?? inst.instructorId ?? inst.InstructorId;

        if (match) {
            assignedInstructorIds.delete(id);
        }
    });

    renderInstructorsList();
}

// ===== אירועים =====
courseSelect.addEventListener("change", () => {
    const courseId = courseSelect.value || null;
    loadCourseAssignments(courseId);
});

instructorFilterInput.addEventListener("input", () => {
    renderInstructorsList();
});

btnSelectAll.addEventListener("click", (e) => {
    e.preventDefault();
    selectAllFiltered();
});

btnClearAll.addEventListener("click", (e) => {
    e.preventDefault();
    clearAllFiltered();
});

btnSaveAssignments.addEventListener("click", (e) => {
    e.preventDefault();
    saveAssignments();
});

// הפעלה ראשונית
init();
