﻿/* css/header.css */
.site-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 16px;
    background-color: #002147; /* כחול BGU */
    color: #fff;
    font-weight: 500;
}

.site-header .title {
    font-size: 1.1rem;
}

.site-header .subtitle {
    font-size: 0.85rem;
    opacity: 0.9;
}
