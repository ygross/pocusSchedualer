const apiBase = "api/api";
const $ = (id) => document.getElementById(id);

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

function getTargets(period) {
  // מודל פשוט (אפשר לשנות בקלות):
  if (period === "week")    return { hours: 8,  instances: 4,  variety: 4 };
  if (period === "quarter") return { hours: 96, instances: 48, variety: 6 };
  // month (קלנדרי)
  return { hours: 32, instances: 16, variety: 4 };
}

function calcLoadIndex(period, totalHours, totalInstances, uniqueActivities) {
  const t = getTargets(period);
  const hoursScore = clamp(totalHours / t.hours, 0, 1);
  const instScore  = clamp(totalInstances / t.instances, 0, 1);
  const varScore   = clamp(uniqueActivities / t.variety, 0, 1);
  return Math.round(100 * (0.6 * hoursScore + 0.3 * instScore + 0.1 * varScore));
}

function loadStyle(loadIndex) {
  if (loadIndex >= 70) return { text: "עומס גבוה 🔴",  color: "var(--bad)" };
  if (loadIndex >= 40) return { text: "עומס בינוני 🟠", color: "var(--brown)" };
  return { text: "עומס נמוך 🟢", color: "var(--green)" };
}

async function safeFetchJson(url) {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status} - ${url}\n${txt}`);
  }
  return res.json();
}

function showErr(msg) {
  const box = $("errBox");
  if (!box) return;
  box.style.display = "block";
  box.textContent = msg;
}
function clearErr() {
  const box = $("errBox");
  if (!box) return;
  box.style.display = "none";
  box.textContent = "";
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* ===== Certifications Pills ===== */
function renderCertifications(certs) {
  const wrap = $("certifications");
  if (!wrap) return;

  wrap.innerHTML = "";

  if (!Array.isArray(certs) || certs.length === 0) {
    wrap.innerHTML = `<span class="cert-pill muted">אין הסמכות</span>`;
    return;
  }

  certs.forEach(c => {
    const pill = document.createElement("span");
    pill.className = "cert-pill";
    pill.textContent = c;
    wrap.appendChild(pill);
  });
}

/* ===== Activities table ===== */
function renderActivitiesTable(rows) {
  const tbody = $("activitiesTable");
  if (!tbody) return;

  const by = Array.isArray(rows) ? rows : [];
  tbody.innerHTML = "";

  if (!by.length) {
    tbody.innerHTML = `<tr><td colspan="3" class="muted">אין נתונים לתקופה שנבחרה</td></tr>`;
    return;
  }

  by.forEach(a => {
    // תומך גם camelCase וגם PascalCase
    const name = a.activityName ?? a.ActivityName ?? "—";
    const instances = Number(a.instances ?? a.Instances ?? 0);
    const hours = Number(a.hours ?? a.Hours ?? 0);

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(name)}</td>
      <td>${instances}</td>
      <td>${hours.toFixed(1)}</td>
    `;
    tbody.appendChild(tr);
  });
}

/* ===== Load Me ===== */
async function loadMe() {
  const me = await safeFetchJson(`${apiBase}/me`);

  const fullName = me?.fullName ?? me?.FullName ?? "—";
  const roleName = me?.roleName ?? me?.RoleName ?? me?.role ?? me?.Role ?? "—";
  const email    = me?.email ?? me?.Email ?? "—";
  const dept     = me?.department ?? me?.Department ?? "";

  $("loggedRole").textContent = `תפקיד המשתמש המחובר שביצע לוגין דרך OTP: ${fullName} (${roleName})`;

  const details = $("instructorDetails");
  if (details) {
    details.innerHTML = `
      <div><b>שם:</b> ${escapeHtml(fullName)}</div>
      <div><b>תפקיד:</b> ${escapeHtml(roleName)}</div>
      ${dept ? `<div><b>מחלקה:</b> ${escapeHtml(dept)}</div>` : ``}
      <div><b>אימייל:</b> ${escapeHtml(email)}</div>
    `;
  }

  return me;
}

/* ===== Load Certifications ===== */
async function loadCerts() {
  // דורש backend endpoint: /api/api/instructors/certifications
  const certs = await safeFetchJson(`${apiBase}/instructors/certifications`);
  renderCertifications(certs);
}

/* ===== Load Stats ===== */
async function loadStats() {
  const period = $("periodSelect")?.value || "month";
  const data = await safeFetchJson(`${apiBase}/instructors/stats?period=${encodeURIComponent(period)}`);

  // תומך גם camelCase וגם PascalCase
  const totalInstances = Number(data.totalInstances ?? data.TotalInstances ?? 0);
  const totalHours     = Number(data.totalHours ?? data.TotalHours ?? 0);
  const byActivity     = data.byActivity ?? data.ByActivity ?? [];

  $("totalInstances").textContent = String(totalInstances);
  $("totalHours").textContent = totalHours.toFixed(1);
  $("loadHoursPill").textContent = `${totalHours.toFixed(1)} שעות`;

  renderActivitiesTable(byActivity);

  const uniqueActivities = Array.isArray(byActivity) ? byActivity.length : 0;
  $("loadInfo").textContent = `${uniqueActivities} פעילויות שונות`;

  const loadIndex = calcLoadIndex(period, totalHours, totalInstances, uniqueActivities);
  $("loadIndex").textContent = String(loadIndex);

  const st = loadStyle(loadIndex);
  $("loadLabel").textContent = st.text;

  const bar = $("loadBar");
  if (bar) {
    bar.style.width = `${loadIndex}%`;
    bar.style.background = st.color;
  }
  const dot = $("loadDot");
  if (dot) dot.style.background = st.color;
}

/* ===== Refresh all ===== */
async function refreshAll() {
  clearErr();
  try {
    await loadMe();
    await loadCerts();
    await loadStats();
  } catch (e) {
    console.error(e);
    showErr("שגיאה בטעינת הנתונים:\n" + (e?.message || e));
  }
}

document.addEventListener("DOMContentLoaded", () => {
  $("btnRefresh")?.addEventListener("click", refreshAll);
  $("periodSelect")?.addEventListener("change", () => {
    loadStats().catch(e => showErr(e?.message || e));
  });

  refreshAll();
});
