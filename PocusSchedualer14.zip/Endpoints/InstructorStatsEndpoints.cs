// Api/Endpoints/InstructorStatsEndpoints.cs
// מלא - מותאם לפרויקט שלך (namespace PocusSchedualer.Endpoints)
// month = כל החודש הקלנדרי (מ-1 עד תחילת החודש הבא), לפי שעון ישראל, כולל עתיד
// week = 7 ימים אחורה (עד עכשיו)
// quarter = 3 חודשים קלנדריים (מתחילת חודש לפני חודשיים עד תחילת חודש הבא), לפי שעון ישראל

using System.Security.Claims;
using PocusSchedualer.Api.Dtos;

namespace PocusSchedualer.Endpoints;

public static class InstructorStatsEndpoints
{
    public static void MapInstructorStatsEndpoints(this WebApplication app)
    {
        // נתיב "האמיתי" שלך (לפי /api/api/me)
        app.MapGet("/api/api/instructors/stats", Handle);

        // Alias חסין
        app.MapGet("/api/instructors/stats", Handle);
    }

    private static async Task<IResult> Handle(HttpContext ctx, string? period, Db db)
    {
        // הזדהות לפי Email מה-Claims (כמו שאר ה-endpoints אצלך)
        var email = ctx.User.FindFirstValue(ClaimTypes.Email);
        if (string.IsNullOrWhiteSpace(email))
            return Results.Unauthorized();

        var me = await db.GetMeByEmailAsync(email);
        if (me == null)
            return Results.Unauthorized();

        var (fromUtc, toUtc) = ResolveRange(period);

        InstructorStatsDto dto = await db.GetInstructorStatsAsync(me.InstructorId, fromUtc, toUtc);
        return Results.Ok(dto);
    }

    private static (DateTime FromUtc, DateTime ToUtc) ResolveRange(string? period)
    {
        var p = (period ?? "month").Trim().ToLowerInvariant();

        // שעון ישראל (Windows)
        var tz = TimeZoneInfo.FindSystemTimeZoneById("Israel Standard Time");

        // עכשיו מקומי
        var nowLocal = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tz);

        // תחילת החודש הנוכחי (01 בחודש, 00:00) - Local
        var monthStartLocal = new DateTime(
            nowLocal.Year,
            nowLocal.Month,
            1,
            0, 0, 0,
            DateTimeKind.Unspecified);

        // תחילת החודש הבא - Local (בלעדי)
        var nextMonthStartLocal = monthStartLocal.AddMonths(1);

        // המרה ל-UTC
        var monthFromUtc = TimeZoneInfo.ConvertTimeToUtc(monthStartLocal, tz);
        var monthToUtc   = TimeZoneInfo.ConvertTimeToUtc(nextMonthStartLocal, tz);

        return p switch
        {
            // 7 ימים אחורה עד עכשיו (ביצוע/עבר קרוב)
            "week" => (DateTime.UtcNow.AddDays(-7), DateTime.UtcNow),

            // רבעון קלנדרי מתגלגל: מתחילת חודש לפני חודשיים עד תחילת חודש הבא
            // (כלומר 3 חודשים קלנדריים: הקודם-קודם, הקודם, הנוכחי)
            "quarter" =>
            (
                TimeZoneInfo.ConvertTimeToUtc(monthStartLocal.AddMonths(-2), tz),
                monthToUtc
            ),

            // חודש קלנדרי מלא: מה-1 עד תחילת החודש הבא (כולל עתיד בתוך החודש)
            "month" => (monthFromUtc, monthToUtc),

            _ => (monthFromUtc, monthToUtc),
        };
    }
}
