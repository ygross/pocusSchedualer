using System.Security.Claims;

namespace PocusSchedualer.Endpoints;

public static class InstructorCertEndpoints
{
    public static void MapInstructorCertEndpoints(this WebApplication app)
    {
        app.MapGet("/api/api/instructors/certifications", Handle);
        app.MapGet("/api/instructors/certifications", Handle); // alias
    }

    private static async Task<IResult> Handle(HttpContext ctx, Db db)
    {
        var email = ctx.User.FindFirstValue(ClaimTypes.Email);
        if (string.IsNullOrWhiteSpace(email)) return Results.Unauthorized();

        var me = await db.GetMeByEmailAsync(email);
        if (me == null) return Results.Unauthorized();

        var certs = await db.GetInstructorCertificationsAsync(me.InstructorId);
        return Results.Ok(certs);
    }
}
