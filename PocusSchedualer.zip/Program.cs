using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Cryptography;
using System.Net;
using System.Net.Mail;







var builder = WebApplication.CreateBuilder(args);

// שירות ה-DB
builder.Services.AddSingleton<Db>();
builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name = "SimPocusAuth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.None;
        options.Cookie.SameSite = SameSiteMode.Lax;

         
    });

builder.Services.AddAuthorization();

var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();
bool IsDevBypassAllowed(string email, IConfiguration cfg, IWebHostEnvironment env)
{
    if (!env.IsDevelopment()) return false;

    var enabled = cfg.GetValue<bool>("Otp:DevBypassEnabled");
    if (!enabled) return false;

    var emails = cfg.GetSection("Otp:DevBypassEmails").Get<string[]>() ?? Array.Empty<string>();
    return emails.Any(e => string.Equals(e, email, StringComparison.OrdinalIgnoreCase));
}

app.MapGet("/api/health/db", async (Db db) =>
{
    var ok = await db.IsDbAliveAsync();
    return Results.Ok(new { ok });
});

 app.MapPost("/api/auth/otp/request", async (
    HttpContext ctx,
    OtpRequestDto dto,
    Db db,
    IConfiguration cfg) =>
{
    var email = dto.Email?.Trim().ToLower();
    if (string.IsNullOrEmpty(email))
        return Results.BadRequest();

    // חייב להיות מדריך קיים
    var me = await db.GetMeByEmailAsync(email);
    if (me == null)
        return Results.Unauthorized();

    var minutes = cfg.GetValue("Otp:ExpireMinutes", 10);
    var code = Db.GenerateOtpCode();
    var salt = Db.GenerateSalt();
    var hash = Db.HashOtp(code, salt);

    await db.CreateOtpAsync(
        email,
        hash,
        salt,
        DateTime.UtcNow.AddMinutes(minutes),
        ctx.Connection.RemoteIpAddress?.ToString(),
        ctx.Request.Headers.UserAgent.ToString(),
        maxAttempts: 6
    );

    // TODO: SMTP – כרגע מספיק שזה נוצר
    Console.WriteLine($"[DEV OTP] {email} = {code}");
var subject = "Pocus Scheduler - קוד התחברות (OTP)";
var body = $@"
<div style=""font-family:Arial;direction:rtl"">
  <h3>קוד התחברות למערכת</h3>
  <div>הקוד שלך הוא:</div>
  <div style=""font-size:28px;font-weight:bold;letter-spacing:3px;margin:10px 0"">{code}</div>
  <div>תוקף הקוד: {minutes} דקות.</div>
</div>";

// יצירת OTP

var expiresUtc = DateTime.UtcNow.AddMinutes(minutes);
var ip = ctx.Connection.RemoteIpAddress?.ToString();
var ua = ctx.Request.Headers.UserAgent.ToString();

var otpId = await db.CreateOtpAsync( email,hash, salt,expiresUtc,ip,ua, maxAttempts: 6);

await db.EnqueueEmailAsync(email, subject, body, "OtpCodes", otpId.ToString());
 try
    {
        await SendEmailSmtpAsync(cfg, email, subject, body);
    }
    catch (Exception ex)
    {
        Console.WriteLine("[SMTP ERROR] " + ex);
        return Results.Problem("Failed to send OTP email");
    }
    return Results.Ok();
});
app.MapPost("/api/auth/otp/verify", async (
    HttpContext ctx,
    OtpVerifyDto dto,
    Db db) =>
{
    var email = dto.Email?.Trim().ToLower();
    var code  = dto.Code?.Trim();

    if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(code))
        return Results.BadRequest();

    var otp = await db.GetLatestOtpAsync(email);
    if (otp == null) return Results.Unauthorized();

    var (hash, salt, attempts, maxAttempts, used, expires) = otp.Value;

    if (used || attempts >= maxAttempts || DateTime.UtcNow > expires)
        return Results.Unauthorized();

    var calc = Db.HashOtp(code, salt);
    if (!CryptographicOperations.FixedTimeEquals(calc, hash))
    {
        await db.IncrementOtpAttemptsAsync(email);
        return Results.Unauthorized();
    }

    await db.MarkOtpUsedAsync(email);

    var me = await db.GetMeByEmailAsync(email);
    if (me == null) return Results.Unauthorized();

    var claims = new List<Claim>
    {
        new Claim(ClaimTypes.Email, me.Email),
        new Claim(ClaimTypes.Role, me.RoleName),
        new Claim("fullName", me.FullName),
        new Claim("department", me.Department ?? ""),
        new Claim("instructorId", me.InstructorId.ToString())
    };

    var id = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
    await ctx.SignInAsync(
        CookieAuthenticationDefaults.AuthenticationScheme,
        new ClaimsPrincipal(id)
    );

    return Results.Ok();
});



app.MapPost("/api/auth/impersonate", async (HttpContext ctx, Db db, ImpersonateReq req) =>
{
    var email = (req.Email ?? "").Trim().ToLowerInvariant();

    // ✅ זמני בלבד – רק המשתמש הזה
    if (email != "ygross@bgu.ac.il")
        return Results.Forbid();

    var me = await db.ImpersonateByEmailAsync(email);
    if (me == null) return Results.Unauthorized();

    // ✅ Claims מה-DB
    var claims = new List<Claim>
    {
        new Claim(ClaimTypes.Email, me.Email),
        new Claim("fullName", me.FullName),
        new Claim(ClaimTypes.Role, me.RoleName),
        new Claim("department", me.Department ?? "")
    };

    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
    var principal = new ClaimsPrincipal(identity);

    await ctx.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

    return Results.Ok(new { ok = true });
});
app.MapGet("/api/activities/calendar", async (
    DateTime from,
    DateTime to,
    int? activityTypeId,
    Db db) =>
{
    try
    {
        // מניח שה־from/to מתקבלים כ־local time וממיר ל־UTC
        var fromUtc = DateTime.SpecifyKind(from, DateTimeKind.Local).ToUniversalTime();
        var toUtc   = DateTime.SpecifyKind(to,   DateTimeKind.Local).ToUniversalTime();

        var rows = await db.GetActivitiesCalendarAsync(fromUtc, toUtc, activityTypeId);
        return Results.Ok(rows);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});
app.MapGet("/api/me", async (HttpContext ctx, Db db) =>
{
    if (ctx.User?.Identity?.IsAuthenticated != true)
        return Results.Unauthorized();

    var email = ctx.User.FindFirstValue(ClaimTypes.Email);
    if (string.IsNullOrWhiteSpace(email))
        return Results.Unauthorized();

    var me = await db.GetMeByEmailAsync(email);
    if (me == null) return Results.Unauthorized();

    return Results.Ok(me);
});

app.MapGet("/api/activity-types", async (Db db) =>
{
    try { return Results.Ok(await db.GetActivityTypesAsync()); }
    catch (Exception ex) { return Results.Problem(ex.Message); }
});

app.MapGet("/api/courses/by-type/{activityTypeId:int}", async (int activityTypeId, Db db) =>
{
    try { return Results.Ok(await db.GetCoursesByActivityTypeAsync(activityTypeId)); }
    catch (Exception ex) { return Results.Problem(ex.Message); }
});

app.MapGet("/api/instructors/by-course/{courseId:int}", async (int courseId, Db db) =>
{
    try { return Results.Ok(await db.GetInstructorsByCourseAsync(courseId)); }
    catch (Exception ex) { return Results.Problem(ex.Message); }
});

// =======================
// Courses / Instructors / Course-Instructors
// =======================

app.MapGet("/api/api/courses", async (Db db) =>
{
    return Results.Ok(await db.GetCoursesAsync());
});

app.MapGet("/api/api/instructors", async (Db db) =>
{
    return Results.Ok(await db.GetInstructorsAsync());
});

app.MapGet("/api/api/course-instructors/{courseId:int}", async (int courseId, Db db) =>
{
    return Results.Ok(await db.GetInstructorIdsForCourseAsync(courseId));
});

app.MapPut("/api/api/course-instructors/{courseId:int}", async (
    int courseId,
    CourseInstructorsPut body,
    Db db) =>
{
    if (body?.InstructorIds == null)
        return Results.BadRequest("Missing instructorIds");

    await db.SetCourseInstructorsAsync(
        courseId,
        body.InstructorIds.Distinct().ToList()
    );

    return Results.NoContent();
});




app.MapPost("/api/activities/create", async (ActivityCreateDto dto, Db db) =>
{
    try
    {
        if (string.IsNullOrWhiteSpace(dto.ActivityName))
            return Results.BadRequest("ActivityName is required");
        if (dto.ActivityTypeId <= 0)
            return Results.BadRequest("ActivityTypeId is required");
        if (dto.CourseId <= 0)
            return Results.BadRequest("CourseId is required");
        if (dto.LeadInstructorId <= 0)
            return Results.BadRequest("LeadInstructorId is required");
        if (dto.Instances == null || dto.Instances.Count == 0)
            return Results.BadRequest("At least one instance is required");

        var id = await db.CreateActivityAsync(dto);

        return Results.Ok(new { status="Created", activityId=id, instances=dto.Instances.Count });
    }
    catch (Exception ex) { return Results.Problem(ex.Message); }
});
app.MapPost("/api/otp/verify", (OtpVerifyDto dto, IConfiguration cfg, IWebHostEnvironment env) =>
{
    // ✅ DEV BYPASS (בדיקות בלבד)
    if (IsDevBypassAllowed(dto.Email, cfg, env))
    {
        var devCode = cfg.GetValue<string>("Otp:DevBypassCode") ?? "123456";
        if (dto.Code == devCode)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, dto.Email),
                new Claim(ClaimTypes.Email, dto.Email),
                new Claim(ClaimTypes.Role, "Admin")
            };

            return Results.Ok(new { ok = true, bypass = true, email = dto.Email });
        }

        return Results.Unauthorized();
    }

    return Results.Unauthorized(); // ← חשוב: מה קורה אם לא bypass
});

app.UseDefaultFiles();
app.UseStaticFiles();

app.Run();


static async Task SendEmailSmtpAsync(
    IConfiguration cfg,
    string to,
    string subject,
    string bodyHtml)
{
    var host = cfg["Smtp:Host"] ?? throw new Exception("Missing Smtp:Host");
    var port = int.Parse(cfg["Smtp:Port"] ?? "587");
    var enableSsl = bool.Parse(cfg["Smtp:EnableSsl"] ?? "true");
    var user = cfg["Smtp:User"] ?? "";
    var pass = cfg["Smtp:Pass"] ?? "";
    var from = cfg["Smtp:From"] ?? user;

    using var client = new SmtpClient(host, port)
    {
        EnableSsl = enableSsl,
        Credentials = new NetworkCredential(user, pass),
    };

    using var msg = new MailMessage(from, to, subject, bodyHtml)
    {
        IsBodyHtml = true
    };

    await client.SendMailAsync(msg);
}
