﻿const err = document.getElementById("err");
const otpBlock = document.getElementById("otpBlock");

async function requestOtp(){
  err.textContent = "";
  const email = document.getElementById("email").value.trim();
  if(!email){ err.textContent="נא להזין אימייל"; return; }

  const res = await fetch("/api/auth/request-otp", {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ email })
  });

  const data = await res.json();

  if(data.status === "OK"){
    otpBlock.style.display = "block";
  } else {
    err.textContent = data.message || data.status || "שגיאה";
  }
}

async function verifyOtp(){
  err.textContent = "";
  const email = document.getElementById("email").value.trim();
  const code  = document.getElementById("otp").value.trim();
  if(!code){ err.textContent="נא להזין קוד"; return; }

  const res = await fetch("/api/auth/verify-otp", {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ email, code })
  });

  const data = await res.json();

  if(data.status === "OK"){
    location.href = "/app.html";
  } else {
    err.textContent = data.message || data.status || "שגיאה";
  }
}
