using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Security.Cryptography;
using System.Text;

public sealed class Db
{
    private readonly IConfiguration _cfg;
    public Db(IConfiguration cfg) => _cfg = cfg;

    private string ConnString =>
        _cfg.GetConnectionString("PocusSchedualer")
        ?? _cfg.GetConnectionString("SimLoanDb")
        ?? _cfg.GetConnectionString("DefaultConnection")
        ?? throw new Exception("Missing connection string (PocusSchedualer / SimLoanDb / DefaultConnection)");

    private SqlConnection NewConnection()
    {
        var c = new SqlConnection(ConnString);
        c.Open();
        return c;
    }

    public SqlConnection Open() => NewConnection();

    // ✅ DB Health (לנקודה /health/db)
public async Task<bool> IsDbAliveAsync()
{
    await using var c = Open();
    var x = await c.QuerySingleAsync<int>("SELECT 1;");
    return x == 1;
}
 

// ================= OTP =================

public async Task<long> CreateOtpAsync(
    string email,
    byte[] hash,
    byte[] salt,
    DateTime expiresUtc,
    string? ip,
    string? ua,
    int maxAttempts)
{
    const string sql = @"
INSERT INTO dbo.OtpCodes
(Email, CodeHash, Salt, CreatedAtUtc, ExpiresAtUtc, Attempts, MaxAttempts, IsUsed, RequestIp, UserAgent)
OUTPUT INSERTED.OtpId
VALUES
(@Email, @Hash, @Salt, SYSUTCDATETIME(), @ExpiresAtUtc, 0, @MaxAttempts, 0, @Ip, @Ua);";

    await using var c = Open();
    return await c.QuerySingleAsync<long>(sql, new {
        Email = email,
        Hash = hash,
        Salt = salt,
        ExpiresAtUtc = expiresUtc,
        MaxAttempts = maxAttempts,
        Ip = ip,
        Ua = ua
    });
}

public async Task<(byte[] Hash, byte[] Salt, int Attempts, int MaxAttempts, bool IsUsed, DateTime Expires)?>
    GetLatestOtpAsync(string email)
{
    const string sql = @"
SELECT TOP 1
  CodeHash   AS Hash,
  Salt,
  Attempts,
  MaxAttempts,
  IsUsed,
  ExpiresAtUtc AS Expires
FROM dbo.OtpCodes
WHERE Email = @Email
ORDER BY OtpId DESC;";

    await using var c = Open();
    return await c.QueryFirstOrDefaultAsync<
        (byte[] Hash, byte[] Salt, int Attempts, int MaxAttempts, bool IsUsed, DateTime Expires)
    >(sql, new { Email = email });
}

public async Task IncrementOtpAttemptsAsync(string email)
{
    const string sql = @"
UPDATE dbo.OtpCodes
SET Attempts = Attempts + 1
WHERE OtpId = (
    SELECT TOP 1 OtpId FROM dbo.OtpCodes
    WHERE Email = @Email ORDER BY OtpId DESC
);";
    await using var c = Open();
    await c.ExecuteAsync(sql, new { Email = email });
}

public async Task MarkOtpUsedAsync(string email)
{
    const string sql = @"
UPDATE dbo.OtpCodes
SET IsUsed = 1
WHERE OtpId = (
    SELECT TOP 1 OtpId FROM dbo.OtpCodes
    WHERE Email = @Email ORDER BY OtpId DESC
);";
    await using var c = Open();
    await c.ExecuteAsync(sql, new { Email = email });
}

// ===== helpers =====
public static string GenerateOtpCode() =>
    RandomNumberGenerator.GetInt32(0, 1_000_000).ToString("D6");

public static byte[] GenerateSalt()
{
    var s = new byte[16];
    RandomNumberGenerator.Fill(s);
    return s;
}

public static byte[] HashOtp(string code, byte[] salt)
{
    using var sha = SHA256.Create();
    var c = Encoding.UTF8.GetBytes(code);
    var all = new byte[c.Length + salt.Length];
    Buffer.BlockCopy(c, 0, all, 0, c.Length);
    Buffer.BlockCopy(salt, 0, all, c.Length, salt.Length);
    return sha.ComputeHash(all);
}
public async Task<long> EnqueueEmailAsync(string toEmail, string subject, string bodyHtml, string? relatedEntity, string? relatedId)
{
    const string sql = @"
INSERT INTO dbo.EmailOutbox
(ToEmail, Subject, BodyHtml, RelatedEntity, RelatedId, Status, CreatedAtUtc)
OUTPUT INSERTED.EmailId
VALUES
(@ToEmail, @Subject, @BodyHtml, @RelatedEntity, @RelatedId, 'Queued', SYSUTCDATETIME());";

    await using var c = Open();
    return await c.QuerySingleAsync<long>(sql, new
    {
        ToEmail = toEmail,
        Subject = subject,
        BodyHtml = bodyHtml,
        RelatedEntity = relatedEntity,
        RelatedId = relatedId
    });
}

// =======================
// Courses / Instructors (FULL LIST)
// =======================

public async Task<List<CourseDto>> GetCoursesAsync()
{
    const string sql = @"
        SELECT CourseId, CourseName, ActivityTypeId
        FROM dbo.Courses
        ORDER BY CourseName;";
    await using var c = Open();
    return (await c.QueryAsync<CourseDto>(sql)).AsList();
}

public async Task<List<InstructorDto>> GetInstructorsAsync()
{
    const string sql = @"
        SELECT InstructorId, FullName, Email
        FROM dbo.Instructors
        ORDER BY FullName;";
    await using var c = Open();
    return (await c.QueryAsync<InstructorDto>(sql)).AsList();
}

// =======================
// Course ↔ Instructor (CERTIFICATIONS)
// =======================

public async Task<List<int>> GetInstructorIdsForCourseAsync(int courseId)
{
    const string sql = @"
        SELECT InstructorId
        FROM dbo.InstructorCourses
        WHERE CourseId = @courseId;";
    await using var c = Open();
    return (await c.QueryAsync<int>(sql, new { courseId })).AsList();
}

public async Task SetCourseInstructorsAsync(int courseId, List<int> instructorIds)
{
    const string deleteSql = @"
        DELETE FROM dbo.InstructorCourses
        WHERE CourseId = @courseId;";

    const string insertSql = @"
        INSERT INTO dbo.InstructorCourses (CourseId, InstructorId)
        VALUES (@courseId, @instructorId);";

    await using var c = Open();
    using var tx = c.BeginTransaction();

    try
    {
        await c.ExecuteAsync(deleteSql, new { courseId }, tx);

        foreach (var instructorId in instructorIds)
        {
            await c.ExecuteAsync(insertSql,
                new { courseId, instructorId },
                tx);
        }

        tx.Commit();
    }
    catch
    {
        tx.Rollback();
        throw;
    }
}

// ✅ Get Me (לנקודה /me)
public async Task<MeDto?> GetMeByEmailAsync(string email)
{
    const string sql = @"
SELECT TOP 1
  InstructorId,
  Email,
  FullName,
  [Role] AS RoleName,
  Department
FROM dbo.Instructors
WHERE Email = @email;";
    await using var c = Open();
    return await c.QueryFirstOrDefaultAsync<MeDto>(sql, new { email });
}

// ✅ Impersonate (לכפתור הזמני ב-Header)
public async Task<MeDto?> ImpersonateByEmailAsync(string email)
{
    // כרגע אותו דבר כמו GetMeByEmailAsync (אפשר להשאיר כ- wrapper)
    return await GetMeByEmailAsync(email);
}


    public async Task<DateTime> GetDbTimeAsync()
    {
        await using var c = NewConnection();
        return await c.QuerySingleAsync<DateTime>("SELECT GETDATE()");
    }

    // ≡≡ פעילות לפי סוג ≡≡
    public async Task<IEnumerable<ActivityTypeDto>> GetActivityTypesAsync()
    {
        const string sql = @"SELECT ActivityTypeId, TypeName FROM dbo.ActivityTypes ORDER BY TypeName;";
        await using var c = NewConnection();
        return await c.QueryAsync<ActivityTypeDto>(sql);
    }
    // ≡≡ קלנדר מופעי פעילויות ≡≡
public async Task<IEnumerable<ActivityCalendarItemDto>> GetActivitiesCalendarAsync(
    DateTime fromUtc,
    DateTime toUtc,
    int? activityTypeId)
{
    const string sql = @"
    SELECT
        a.ActivityId,
        a.ActivityName,
        a.ActivityTypeId,
        t.TypeName,
        a.CourseId,
        c.CourseName,
        a.LeadInstructorId,
        i.FullName AS LeadInstructorName,
        inst.StartUtc,
        inst.EndUtc
    FROM dbo.ActivityInstances inst
    JOIN dbo.Activities a
        ON a.ActivityId = inst.ActivityId
    JOIN dbo.ActivityTypes t
        ON t.ActivityTypeId = a.ActivityTypeId
    LEFT JOIN dbo.Courses c
        ON c.CourseId = a.CourseId
    LEFT JOIN dbo.Instructors i
        ON i.InstructorId = a.LeadInstructorId
    WHERE inst.StartUtc >= @fromUtc
      AND inst.StartUtc <  @toUtc
      AND (@activityTypeId IS NULL OR a.ActivityTypeId = @activityTypeId)
    ORDER BY inst.StartUtc;";

    await using var c = Open();
    return await c.QueryAsync<ActivityCalendarItemDto>(sql, new
    {
        fromUtc,
        toUtc,
        activityTypeId
    });
}


    // ≡≡ קורסים לפי סוג פעילות ≡≡
    public async Task<IEnumerable<CourseDto>> GetCoursesByActivityTypeAsync(int activityTypeId)
    {
        const string sql = @"
        SELECT CourseId, CourseName, ActivityTypeId
        FROM dbo.Courses
        WHERE ActivityTypeId=@activityTypeId
        ORDER BY CourseName;";

        await using var c = NewConnection();
        return await c.QueryAsync<CourseDto>(sql, new { activityTypeId });
    }

    // ≡≡ מדריכים לפי קורס ≡≡
    public async Task<IEnumerable<InstructorDto>> GetInstructorsByCourseAsync(int courseId)
    {
        const string sql = @"
             SELECT i.InstructorId, i.FullName, i.Email
        FROM dbo.Instructors i
        JOIN dbo.InstructorCourses ci ON ci.InstructorId=i.InstructorId
        WHERE ci.CourseId=@courseId
        ORDER BY i.FullName;";

        await using var c = NewConnection();
        return await c.QueryAsync<InstructorDto>(sql,new{courseId});
    }

    // 🚀 יצירת פעילות — כולל CourseId שמור ב-DB!
    public async Task<int> CreateActivityAsync(ActivityCreateDto request)
    {
        const string sql = @"
        INSERT INTO dbo.Activities
        (ActivityName, ActivityTypeId, Department, CourseId,
         ApplicationDeadlineUtc, CreatedByInstructorId,
         IsCancelled, CancelReason,
         CreatedAtUtc, UpdatedAtUtc, LeadInstructorId)
        OUTPUT INSERTED.ActivityId
        VALUES
        (@ActivityName, @ActivityTypeId,'',
         @CourseId, @ApplicationDeadlineUtc,
         @LeadInstructorId,0,NULL,
         SYSUTCDATETIME(),SYSUTCDATETIME(),
         @LeadInstructorId);";

        await using var c = Open();
        return await c.QuerySingleAsync<int>(sql, request);
    }
}
