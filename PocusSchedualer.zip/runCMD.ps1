﻿dotnet publish -c Release -o "E:\inetpub\wwwroot\simcenter\PocusSchedualer\api"
pause