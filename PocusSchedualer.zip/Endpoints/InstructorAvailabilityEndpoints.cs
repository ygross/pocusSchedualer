using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace PocusSchedualer.Endpoints;

/// <summary>
/// Instructor availability endpoints
///
/// Routes:
///   POST   /api/instructors/instances/{instanceId}/availability   -> offer availability (for ME)
///   DELETE /api/instructors/instances/{instanceId}/availability   -> cancel availability (for ME)
///
/// Authorization:
///   - Requires authenticated user with instructorId (myInstructorId) claim (same mechanism as /api/me).
///   - Allowed roles: Instructor / CourseManager / Admin
///
/// Behavior:
///   - If instructor already assigned to the instance -> 409 Conflict
/// </summary>
public static class InstructorAvailabilityEndpoints
{
    public static void MapInstructorAvailabilityEndpoints(this WebApplication app)
    {
        app.MapPost("/api/instructors/instances/{instanceId:int}/availability", async (
            HttpContext ctx,
            int instanceId,
            Db db) =>
        {
            var (isAuth, myInstructorId) = TryGetMyInstructorId(ctx);
            if (!isAuth || myInstructorId == null) return Results.Unauthorized();

            if (!IsAllowed(ctx)) return Results.Forbid();

            // אם כבר שובצת - לא מאפשרים שינוי
            if (await db.IsInstructorAssignedToInstanceAsync(instanceId, myInstructorId.Value))
                return Results.Conflict(new { ok = false, error = "Assigned instance is locked." });

            await db.UpsertInstructorAvailabilityAsync(instanceId, myInstructorId.Value);
            return Results.Ok(new { ok = true });
        });

        app.MapDelete("/api/instructors/instances/{instanceId:int}/availability", async (
            HttpContext ctx,
            int instanceId,
            Db db) =>
        {
            var (isAuth, myInstructorId) = TryGetMyInstructorId(ctx);
            if (!isAuth || myInstructorId == null) return Results.Unauthorized();

            if (!IsAllowed(ctx)) return Results.Forbid();

            if (await db.IsInstructorAssignedToInstanceAsync(instanceId, myInstructorId.Value))
                return Results.Conflict(new { ok = false, error = "Assigned instance is locked." });

            await db.DeleteInstructorAvailabilityAsync(instanceId, myInstructorId.Value);
            return Results.Ok(new { ok = true });
        });
    }

    private static bool IsAllowed(HttpContext ctx) =>
        ctx.User.IsInRole("Instructor") || ctx.User.IsInRole("CourseManager") || ctx.User.IsInRole("Admin");

    /// <summary>
    /// Reads instructor id from claims. Update this if your claim name differs.
    /// Common names I saw in your code base: "myInstructorId", "InstructorId".
    /// </summary>
    private static (bool isAuth, int? myInstructorId) TryGetMyInstructorId(HttpContext ctx)
    {
        if (ctx?.User?.Identity?.IsAuthenticated != true) return (false, null);

        var v =
            ctx.User.FindFirst("myInstructorId")?.Value ??
            ctx.User.FindFirst("InstructorId")?.Value ??
            ctx.User.FindFirst("instructorId")?.Value;

        return int.TryParse(v, out var id) ? (true, id) : (true, null);
    }
}
