פה תוכל להוסיף בעתיד קבצי Endpoints (Minimal APIs) כמו AuthEndpoints.cs וכו'.
