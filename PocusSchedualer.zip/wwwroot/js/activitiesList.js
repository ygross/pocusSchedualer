// activitiesList.js  (Calendar: monthly + quarterly for assigned instructor)
// Requirements:
// - show ONLY instances the logged-in instructor is assigned to
// - month view and quarter view
// - download ICS locally
// - send ICS by email (via backend endpoint that emails current user)

const $ = (id) => document.getElementById(id);

function setMsg(text, kind = "") {
  const el = $("msg");
  el.className = "msg" + (kind ? " " + kind : "");
  el.textContent = text || "";
}

function esc(s){
  return (s ?? "").toString()
    .replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;")
    .replaceAll('"',"&quot;").replaceAll("'","&#039;");
}

function pad2(n){ return String(n).padStart(2,"0"); }

function toLocalNice(dt){
  if(!dt) return "-";
  const d = new Date(dt);
  return `${pad2(d.getDate())}/${pad2(d.getMonth()+1)}/${d.getFullYear()} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

function ymd(d){
  return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`;
}

function startOfMonth(d){
  return new Date(d.getFullYear(), d.getMonth(), 1, 0,0,0,0);
}

function endOfMonth(d){
  return new Date(d.getFullYear(), d.getMonth()+1, 0, 23,59,59,999);
}

function addMonths(d, n){
  return new Date(d.getFullYear(), d.getMonth()+n, 1, 0,0,0,0);
}

function quarterStart(d){
  const q = Math.floor(d.getMonth()/3)*3;
  return new Date(d.getFullYear(), q, 1, 0,0,0,0);
}

// ---------- API base auto-detect (api vs api/api) ----------
const APP_PATH = new URL(".", window.location.href).pathname; // ends with '/'
const API_CANDIDATES = [
  `${window.location.origin}${APP_PATH}api`,
  `${window.location.origin}${APP_PATH}api/api`
];
let API_BASE = API_CANDIDATES[0];

function EP(){
  return {
    me: `${API_BASE}/me`,

    // You need to implement this endpoint in backend (recommended).
    // Returns assigned instances for current user in [fromUtc,toUtc).
    myAssigned: (fromUtc, toUtc) => `${API_BASE}/me/assigned-instances?fromUtc=${encodeURIComponent(fromUtc)}&toUtc=${encodeURIComponent(toUtc)}`,

    // Optional server-side email sending (recommended):
    emailIcs: `${API_BASE}/me/calendar/ics/email`
  };
}

async function fetchTry(url, opts = {}){
  return await fetch(url, { credentials: "include", ...opts });
}

async function httpJson(url, opts = {}){
  const res = await fetch(url, {
    credentials: "include",
    headers: { "Accept":"application/json", ...(opts.headers || {}) },
    ...opts
  });
  if(!res.ok){
    const t = await res.text().catch(()=> "");
    throw new Error(`${res.status} ${t}`.trim());
  }
  const ct = res.headers.get("content-type") || "";
  if(ct.includes("application/json")) return await res.json();
  return null;
}

async function detectApiBase(){
  for(const cand of API_CANDIDATES){
    const res = await fetchTry(`${cand}/me`);
    if(res.ok){
      API_BASE = cand;
      $("apiBase").textContent = API_BASE;
      return;
    }
  }
  $("apiBase").textContent = API_BASE;
  setMsg(`לא נמצא API תקין. ניסיתי: ${API_CANDIDATES.join(" , ")}`, "err");
}

// ---------- State ----------
let me = null;
let allEvents = [];     // assigned instances
let viewMode = "month"; // "month" | "quarter"
let cursorMonth = startOfMonth(new Date());
let cursorQuarter = quarterStart(new Date());

function applyTextFilter(list){
  const t = ($("fText").value || "").trim().toLowerCase();
  if(!t) return list;
  return list.filter(x => (x.activityName || "").toLowerCase().includes(t));
}

function rangeMonths(){
  const v = Number($("rangeMonths").value || "3") || 3;
  return Math.max(1, Math.min(12, v));
}

// ---------- Load user ----------
async function loadMe(){
  try{
    me = await httpJson(EP().me);
    const name = me.fullName || me.email || "לא ידוע";
    const role = me.roleName || "-";
    $("topUser").textContent = `${name} • ${role}`;
  }catch{
    $("topUser").textContent = "לא מחובר";
  }
}

// ---------- Fetch assigned instances ----------
function toIsoUtc(d){
  // backend expects UTC; we send ISO with Z
  return new Date(d.getTime()).toISOString();
}

async function loadAssigned(){
  // load from today to +rangeMonths months
  const from = new Date();
  const to = new Date();
  to.setMonth(to.getMonth() + rangeMonths());

  setMsg("טוען מופעים משובצים…");
  const data = await httpJson(EP().myAssigned(toIsoUtc(from), toIsoUtc(to)));

  // expected shape:
  // [
  //  { instanceId, activityId, activityName, startUtc, endUtc, location, roomsText, courseName }
  // ]
  allEvents = Array.isArray(data) ? data : [];
  setMsg(`נטענו ${allEvents.length} מופעים משובצים`, "ok");

  render();
}

// ---------- Render: Month ----------
const DOW_SUN0 = 0; // JS: Sunday=0 ... Saturday=6

const MONTH_NAMES = ["ינואר","פברואר","מרץ","אפריל","מאי","יוני","יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר"];

function eventsForDay(dateLocal){
  const dayStart = new Date(dateLocal.getFullYear(), dateLocal.getMonth(), dateLocal.getDate(), 0,0,0,0);
  const dayEnd   = new Date(dateLocal.getFullYear(), dateLocal.getMonth(), dateLocal.getDate(), 23,59,59,999);

  const list = applyTextFilter(allEvents);

  // events stored as UTC strings; compare by Date objects
  return list.filter(e => {
    const s = new Date(e.startUtc);
    return (s >= dayStart && s <= dayEnd);
  }).sort((a,b)=> new Date(a.startUtc) - new Date(b.startUtc));
}

function renderMonth(){
  const title = `${MONTH_NAMES[cursorMonth.getMonth()]} ${cursorMonth.getFullYear()}`;
  $("monthTitle").textContent = title;

  const grid = $("monthGrid");
  grid.innerHTML = "";

  const first = startOfMonth(cursorMonth);
  const last = endOfMonth(cursorMonth);

  // build 6 weeks grid (42 days)
  const start = new Date(first);
  // move to Sunday (rtl header already shows Sun..Sat)
  start.setDate(start.getDate() - start.getDay());

  for(let i=0;i<42;i++){
    const d = new Date(start);
    d.setDate(start.getDate()+i);

    const inMonth = (d.getMonth() === cursorMonth.getMonth());
    const today = ymd(d) === ymd(new Date());

    const dayDiv = document.createElement("div");
    dayDiv.className = "day" + (inMonth ? "" : " muted");
    dayDiv.innerHTML = `
      <div class="dayNum">
        <span>${d.getDate()}</span>
        ${today ? `<span class="pill orange">היום</span>` : ``}
      </div>
      <div class="mini">${inMonth ? "" : MONTH_NAMES[d.getMonth()]}</div>
      <div class="evList" id="ev_${ymd(d)}"></div>
    `;

    const evs = eventsForDay(d);
    const evList = dayDiv.querySelector(".evList");

    // show up to 4, then "+N"
    const maxShow = 4;
    evs.slice(0,maxShow).forEach(ev => {
      const el = document.createElement("div");
      el.className = "ev";
      el.dataset.instanceId = ev.instanceId ?? "";
      el.innerHTML = `
        <div class="evTitle">${esc(ev.activityName || ("פעילות #" + (ev.activityId ?? "")))}</div>
        <div class="evTime">${esc(toLocalNice(ev.startUtc))} - ${esc(toLocalNice(ev.endUtc))}</div>
        <div class="evMeta">${esc(ev.location || ev.roomsText || ev.courseName || "")}</div>
      `;
      el.addEventListener("click", (e) => {
        e.stopPropagation();
        openModal(ev);
      });
      evList.appendChild(el);
    });

    if(evs.length > maxShow){
      const more = document.createElement("div");
      more.className = "mini";
      more.textContent = `+${evs.length - maxShow} נוספים`;
      evList.appendChild(more);
    }

    grid.appendChild(dayDiv);
  }
}

// ---------- Render: Quarter ----------
function monthStart(d, offset){
  return new Date(d.getFullYear(), d.getMonth()+offset, 1, 0,0,0,0);
}

function monthEnd(d, offset){
  return new Date(d.getFullYear(), d.getMonth()+offset+1, 0, 23,59,59,999);
}

function eventsForMonth(ms, me){
  const list = applyTextFilter(allEvents);
  return list.filter(e => {
    const s = new Date(e.startUtc);
    return (s >= ms && s <= me);
  }).sort((a,b)=> new Date(a.startUtc) - new Date(b.startUtc));
}

function renderQuarter(){
  const qs = quarterStart(cursorQuarter);
  const title = `רבעון החל מ־${pad2(qs.getDate())}/${pad2(qs.getMonth()+1)}/${qs.getFullYear()}`;
  $("quarterTitle").textContent = title;

  const wrap = $("qWrap");
  wrap.innerHTML = "";

  for(let i=0;i<3;i++){
    const ms = monthStart(qs, i);
    const me = monthEnd(qs, i);
    const evs = eventsForMonth(ms, me);

    const box = document.createElement("div");
    box.className = "qMonth";
    box.innerHTML = `
      <h3>${MONTH_NAMES[ms.getMonth()]} ${ms.getFullYear()} <span class="pill">${evs.length}</span></h3>
      <div class="qList" id="q_${ms.getFullYear()}_${ms.getMonth()}"></div>
    `;

    const list = box.querySelector(".qList");

    if(evs.length === 0){
      const emp = document.createElement("div");
      emp.className = "mini";
      emp.textContent = "אין מופעים בחודש זה.";
      list.appendChild(emp);
    }else{
      evs.forEach(ev => {
        const item = document.createElement("div");
        item.className = "qItem";
        item.innerHTML = `
          <b>${esc(ev.activityName || ("פעילות #" + (ev.activityId ?? "")))}</b>
          <div class="mini">${esc(toLocalNice(ev.startUtc))} - ${esc(toLocalNice(ev.endUtc))}</div>
          <div class="mini">${esc(ev.location || ev.roomsText || ev.courseName || "")}</div>
        `;
        item.addEventListener("click", ()=> openModal(ev));
        list.appendChild(item);
      });
    }

    wrap.appendChild(box);
  }
}

// ---------- Modal ----------
function openModal(ev){
  $("mTitle").textContent = ev.activityName || "פרטי מופע";
  const body = $("mBody");

  const rows = [
    ["ActivityId", ev.activityId ?? "-"],
    ["InstanceId", ev.instanceId ?? "-"],
    ["התחלה", toLocalNice(ev.startUtc)],
    ["סיום", toLocalNice(ev.endUtc)],
    ["מיקום/חדרים", ev.location || ev.roomsText || "-"],
    ["קורס", ev.courseName || "-"]
  ];

  body.innerHTML = rows.map(([k,v]) => `<div>${esc(k)}</div><div>${esc(v)}</div>`).join("");
  $("modalBack").style.display = "flex";

  $("mCopy").onclick = async () => {
    const txt = rows.map(([k,v])=> `${k}: ${v}`).join("\n");
    try{
      await navigator.clipboard.writeText(txt);
      setMsg("הפרטים הועתקו ללוח", "ok");
    }catch{
      setMsg("לא ניתן להעתיק (חסימת דפדפן).", "err");
    }
  };
}

function closeModal(){
  $("modalBack").style.display = "none";
}

function bindModal(){
  $("mClose").addEventListener("click", closeModal);
  $("mClose2").addEventListener("click", closeModal);
  $("modalBack").addEventListener("click", (e)=> { if(e.target === $("modalBack")) closeModal(); });
  document.addEventListener("keydown", (e)=> { if(e.key === "Escape") closeModal(); });
}

// ---------- View switching ----------
function setView(mode){
  viewMode = mode;
  $("viewMonth").classList.toggle("active", mode==="month");
  $("viewQuarter").classList.toggle("active", mode==="quarter");

  $("monthArea").style.display = (mode==="month") ? "" : "none";
  $("quarterArea").style.display = (mode==="quarter") ? "" : "none";
  render();
}

// ---------- ICS generation (client-side download) ----------
function icsEscape(s){
  return (s ?? "").toString()
    .replaceAll("\\","\\\\")
    .replaceAll("\n","\\n")
    .replaceAll(",","\\,")
    .replaceAll(";","\\;");
}

function toIcsUtc(dt){
  // dt: ISO string or Date
  const d = (dt instanceof Date) ? dt : new Date(dt);
  // YYYYMMDDTHHMMSSZ
  return `${d.getUTCFullYear()}${pad2(d.getUTCMonth()+1)}${pad2(d.getUTCDate())}T${pad2(d.getUTCHours())}${pad2(d.getUTCMinutes())}${pad2(d.getUTCSeconds())}Z`;
}

function buildIcs(events){
  const prodId = "-//BGU SimCenter//Assigned Instances//HE";
  const now = new Date();
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    `PRODID:${prodId}`
  ];

  const list = applyTextFilter(events).slice().sort((a,b)=> new Date(a.startUtc)-new Date(b.startUtc));

  list.forEach(ev => {
    const uid = `${ev.instanceId ?? (ev.activityId + "_" + toIcsUtc(ev.startUtc))}@simsched`;
    const summary = ev.activityName || `Activity ${ev.activityId ?? ""}`;
    const loc = ev.location || ev.roomsText || "";
    const desc = [
      `ActivityId: ${ev.activityId ?? ""}`,
      `InstanceId: ${ev.instanceId ?? ""}`,
      ev.courseName ? `Course: ${ev.courseName}` : ""
    ].filter(Boolean).join("\\n");

    lines.push("BEGIN:VEVENT");
    lines.push(`UID:${icsEscape(uid)}`);
    lines.push(`DTSTAMP:${toIcsUtc(now)}`);
    lines.push(`DTSTART:${toIcsUtc(ev.startUtc)}`);
    lines.push(`DTEND:${toIcsUtc(ev.endUtc)}`);
    lines.push(`SUMMARY:${icsEscape(summary)}`);
    if(loc) lines.push(`LOCATION:${icsEscape(loc)}`);
    if(desc) lines.push(`DESCRIPTION:${icsEscape(desc)}`);
    lines.push("END:VEVENT");
  });

  lines.push("END:VCALENDAR");
  return lines.join("\r\n");
}

function downloadText(filename, content, mime="text/calendar;charset=utf-8"){
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// ---------- Email ICS (server-side) ----------
async function sendIcsByEmail(){
  // recommended: backend generates and emails based on current user
  // we also send a hint payload, but backend can ignore it.
  setMsg("שולח בקשה למייל עם ICS…");

  const payload = {
    rangeMonths: rangeMonths(),
    filterText: ($("fText").value || "").trim()
  };

  const res = await fetch(EP().emailIcs, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type":"application/json", "Accept":"application/json" },
    body: JSON.stringify(payload)
  });

  if(!res.ok){
    const t = await res.text().catch(()=> "");
    throw new Error(`${res.status} ${t}`.trim());
  }

  setMsg("נשלח מייל עם קובץ ICS לכתובת המשתמש המחובר ✅", "ok");
}

// ---------- Render dispatcher ----------
function render(){
  if(viewMode === "month") renderMonth();
  else renderQuarter();
}

// ---------- Bind events ----------
function bind(){
  $("viewMonth").addEventListener("click", ()=> setView("month"));
  $("viewQuarter").addEventListener("click", ()=> setView("quarter"));

  $("btnPrev").addEventListener("click", ()=> { cursorMonth = addMonths(cursorMonth, -1); render(); });
  $("btnNext").addEventListener("click", ()=> { cursorMonth = addMonths(cursorMonth, +1); render(); });
  $("btnToday").addEventListener("click", ()=> { cursorMonth = startOfMonth(new Date()); render(); });

  $("btnQPrev").addEventListener("click", ()=> { cursorQuarter = addMonths(cursorQuarter, -3); cursorQuarter = quarterStart(cursorQuarter); render(); });
  $("btnQNext").addEventListener("click", ()=> { cursorQuarter = addMonths(cursorQuarter, +3); cursorQuarter = quarterStart(cursorQuarter); render(); });
  $("btnQToday").addEventListener("click", ()=> { cursorQuarter = quarterStart(new Date()); render(); });

  $("btnRefresh").addEventListener("click", ()=> loadAssigned().catch(e=> setMsg(e.message, "err")));
  $("rangeMonths").addEventListener("change", ()=> loadAssigned().catch(e=> setMsg(e.message, "err")));
  $("fText").addEventListener("keydown", (e)=> { if(e.key==="Enter") loadAssigned().catch(err=> setMsg(err.message,"err")); });

  $("btnDownloadIcs").addEventListener("click", ()=> {
    try{
      const ics = buildIcs(allEvents);
      const name = `MyAssigned_${me?.email ? me.email.replaceAll("@","_") : "Instructor"}_${Date.now()}.ics`;
      downloadText(name, ics);
      setMsg("ה-ICS ירד למחשב ✅", "ok");
    }catch(e){
      setMsg("שגיאה ביצירת ICS: " + e.message, "err");
    }
  });

  $("btnEmailIcs").addEventListener("click", ()=> {
    sendIcsByEmail().catch(e=> setMsg("שגיאה בשליחה במייל: " + e.message, "err"));
  });

  bindModal();
}

// ---------- Init ----------
(async function init(){
  await detectApiBase();
  await loadMe();
  bind();

  // default cursors
  cursorMonth = startOfMonth(new Date());
  cursorQuarter = quarterStart(new Date());

  await loadAssigned();
})().catch(e => setMsg(e.message, "err"));
